"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useSession, signOut } from "next-auth/react";
import { FaShoppingCart } from "react-icons/fa";
import {
  CalendarDays,
  ChevronDown,
  ClipboardList,
  Gift,
  LayoutDashboard,
  LogOut,
  MapPin,
  Menu as MenuIcon,
  Star,
  UserRound,
  X,
} from "lucide-react";
import { isStaffRole, firstAllowedPath, staffMenuLabel } from "@/lib/permissions";
import { useCart } from "@/context/CartContext";

/**
 * src/components/SiteNavbar.tsx
 *
 * Figma "Frame 2147236005" spec:
 * - Outer row (Frame 2147236004): 1280px wide, justify-between, items-center
 * - Logo (icon 40x40 + "Cuisine" wordmark, gap 12px) — wordmark is BLACK
 *   here (#000000), unlike the footer where it's orange.
 * - Nav links (Frame 2147235235): Home / Menu / Our Chefs / Reservation,
 *   gap 30px. NOTE: the CSS export only accounts for these 4 items
 *   (56+51+92+110 + 3*30 = 399px, matching the frame width exactly) —
 *   there is no "Gift Cards" item in the design, so it's removed here.
 * - Right side (Frame 2147235998): Log In (outline pill) + Sign Up
 *   (gradient pill) + cart button (black circle, 46x46) — logged OUT.
 *   Logged IN: those two pills are replaced by an avatar+chevron trigger
 *   that opens a small dropdown (Admin Dashboard / Logout), and the cart
 *   button stays put. See the FIX note below for why this wasn't showing.
 * - Divider: 1px full-width line at rgba(0,0,0,0.1) under the row.
 *
 * FIX (bg mismatch): the parent frame in Figma (`sections_css.txt`,
 * "Frame 2147236004" — the one wrapping the black top bar + this navbar
 * + the hero content) has `background: #F9F6F3`. This component was
 * previously transparent, so it fell through to whatever the page/layout
 * background happened to be (white in production) instead of the cream
 * tone. Setting the bg explicitly here means the navbar is correct
 * regardless of what wraps it.
 *
 * FIX (dropdown not appearing after Google login): this component never
 * read the session at all — it always rendered the static Log In / Sign
 * Up pills, so the avatar+dropdown you get elsewhere (AccountMenu.tsx,
 * wired into the now-unused TopBar.tsx) never had anywhere to show up
 * here. useSession() is added below so this navbar actually reacts to
 * being logged in. Customers see the customer panel pages (My Account,
 * Orders, Rewards, Reservations, Profile) and Logout; staff see only
 * their dashboard link and Logout.
 *
 * ⚠️ Logo: uses /logo.svg from your public folder directly instead of a
 * hand-drawn shape, since that file already contains the gradient bell
 * mark. Swap the `src` below if your file lives at a different path.
 */

/**
 * ⚠️ "Our Chefs" আগে `/our-chefs`-এ যেত, কিন্তু পাতাটার আসল ঠিকানা
 * `app/(main)/chefs/` — অর্থাৎ লিঙ্কটা 404 দিত। নামের সাথে ফোল্ডারের
 * নাম মিলিয়ে ধরে নেওয়াটাই ভুল ছিল।
 *
 * ⚠️ "Reservation"-এর কোনো পাতা এখনো **নেই** (`app/(main)/`-এ
 * `reservation` ফোল্ডার নেই), তাই ওটা এখনো 404 দেয়। ইচ্ছাকৃতভাবে
 * অন্য কোথাও পাঠাইনি — `/dine-in` বা `/order`-এ পাঠালে খদ্দের যা
 * চাইছেন তার বদলে অন্য জিনিস পেতেন, আর সেটা 404-এর চেয়েও
 * বিভ্রান্তিকর। পাতাটা বানানো না হলে বরং এই সারিটা তালিকা থেকে
 * মুছে ফেলাই ভালো।
 */
/**
 * The customer panel, one tap from the avatar — same list as the panel's
 * own menu (components/account/AccountNav.tsx).
 */
const accountLinks = [
  { label: "My Orders", href: "/account", icon: ClipboardList },
  { label: "Profile Details", href: "/account/profile", icon: UserRound },
  { label: "Loyalty", href: "/account/loyalty", icon: Gift },
  { label: "My Reviews", href: "/account/reviews", icon: Star },
  { label: "Reservations", href: "/my-reservations", icon: CalendarDays },
  { label: "Saved Addresses", href: "/account/addresses", icon: MapPin },
];

const navLinks = [
  { label: "Home", href: "/" },
  { label: "Menu", href: "/menu" },
  { label: "Our Chefs", href: "/chefs" },
  { label: "Reservation", href: "/reservation" },
];

export default function Navbar() {
  /**
   * ⚠️ সংখ্যাটা এখন `useCart()` থেকে, prop থেকে নয়।
   *
   * আগে এটা `cartCount = 0` নামের একটা ঐচ্ছিক prop ছিল, কিন্তু
   * `(main)/layout.tsx` কেবল `<SiteNavbar />` লেখে — কেউ কোনোদিন
   * মানটা পাঠায়নি। ফলে ডিফল্ট শূন্যই থেকে যেত, আর `cartCount > 0`
   * শর্তটা কখনো সত্যি হতো না: cart-এ যাই থাকুক, badge কখনোই
   * দেখা যেত না।
   *
   * layout থেকে পাঠানোও যেত না — ওটা server component, আর cart
   * থাকে browser-এর state-এ। তাই উৎসটাই বদলানো হলো।
   */
  const { cartCount } = useCart();
  const pathname = usePathname();
  const { data: session, status } = useSession();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  // Phone/tablet menu (below lg the nav links don't fit in the row).
  const [mobileOpen, setMobileOpen] = useState(false);
  const mobileRef = useRef<HTMLDivElement>(null);
  // Close the phone menu after navigating (adjusting state during render,
  // not in an effect — the React-recommended way).
  const [menuPath, setMenuPath] = useState(pathname);
  if (menuPath !== pathname) {
    setMenuPath(pathname);
    setMobileOpen(false);
    setMenuOpen(false);
  }

  useEffect(() => {
    if (!mobileOpen) return;
    const onPointerDown = (e: MouseEvent) => {
      if (mobileRef.current && !mobileRef.current.contains(e.target as Node)) setMobileOpen(false);
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMobileOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [mobileOpen]);

  // Close the dropdown on outside click — same pattern as
  // AccountMenu.tsx / AdminTopbar.tsx.
  useEffect(() => {
    if (!menuOpen) return;
    const onPointerDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [menuOpen]);

  const role = (session?.user as { role?: string } | undefined)?.role;
  const showAdminLink = isStaffRole(role);
  const displayName =
    session?.user?.name || session?.user?.email?.split("@")[0] || "Account";

  return (
    <header className="w-full bg-[#F9F6F3]">
      <div className="mx-auto flex w-full max-w-[1280px] flex-col items-start gap-[30px] px-4 pt-5 md:px-10 xl:px-0">
        {/* Row: logo + nav links + auth/cart buttons */}
        {/* ⚠️ Smaller gaps and wordmark below 390px: when signed in, the
            logo + avatar + cart were wider than a 320px phone and the page
            scrolled sideways. From 390px up it's the Figma size. */}
        <div ref={mobileRef} className="relative flex w-full items-center justify-between gap-2 min-[390px]:gap-6">
          {/* Logo */}
          <Link href="/" className="flex min-w-0 shrink-0 items-center gap-1.5 min-[390px]:gap-3">
            <Image
              src="/logo.svg"
              alt="Cuisine logo"
              width={40}
              height={40}
              className="h-9 w-9 min-[390px]:h-10 min-[390px]:w-10"
              priority
            />
            <span className="font-frank-ruhl text-[20px] font-bold leading-[1.26] tracking-[-0.01em] text-black min-[390px]:text-[28px]">
              Cuisine
            </span>
          </Link>

          {/* Nav links — desktop only */}
          <nav className="hidden items-center gap-[30px] lg:flex">
            {navLinks.map((link) => {
              const isActive = pathname === link.href;
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={`font-sora text-[18px] leading-[1.6] transition-colors hover:text-black focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px] ${
                    isActive ? "font-semibold text-[#141921]" : "font-normal text-black/70"
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          {/* Auth buttons + cart */}
          <div className="flex shrink-0 items-center gap-1.5 min-[390px]:gap-2">
            {status === "loading" ? (
              // Session still resolving — avoid a Login/SignUp flash
              // right before it turns into the avatar.
              <div className="h-[46px] w-[46px] animate-pulse rounded-full bg-black/10" />
            ) : session ? (
              // No `relative` here: the dropdown anchors to the whole row, so
              // on a 320px phone it opens inside the screen, not off the left.
              <div ref={menuRef}>
                <button
                  type="button"
                  onClick={() => {
                    setMobileOpen(false);
                    setMenuOpen((prev) => !prev);
                  }}
                  aria-haspopup="menu"
                  aria-expanded={menuOpen}
                  aria-label="Account menu"
                  className="flex h-[42px] items-center gap-2 rounded-full border border-black/10 bg-white pl-1 pr-1 transition-colors min-[390px]:h-[46px] min-[390px]:pr-3 hover:bg-black/[0.03] focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px]"
                >
                  {session.user?.image ? (
                    <Image
                      src={session.user.image}
                      alt=""
                      width={38}
                      height={38}
                      referrerPolicy="no-referrer"
                      className="h-[38px] w-[38px] shrink-0 rounded-full object-cover"
                    />
                  ) : (
                    <span className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full bg-black font-sora text-[14px] font-semibold text-white">
                      {displayName.charAt(0).toUpperCase()}
                    </span>
                  )}
                  {/* ⚠️ min-[640px], not `sm:` — this project's sm is 320px, so
                      `sm:inline` showed the name on phones and pushed the
                      navbar wider than the screen (sideways scrolling). */}
                  <span className="hidden max-w-[120px] truncate font-sora text-[15px] font-semibold text-black min-[640px]:inline">
                    {displayName}
                  </span>
                  <ChevronDown
                    className={`hidden h-4 w-4 shrink-0 text-black/50 transition-transform min-[390px]:block ${
                      menuOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {menuOpen && (
                  <div
                    role="menu"
                    className="absolute right-0 top-full z-50 mt-2 w-[240px] max-w-full rounded-[20px] border border-black/5 bg-white p-2 shadow-[0_12px_32px_rgba(0,0,0,0.14)]"
                  >
                    <div className="truncate px-3.5 pb-2 pt-1 font-sora text-[13px] text-black/50">
                      {session.user?.email}
                    </div>

                    {/* ⚠️ Staff accounts are for work: only their dashboard
                        and Logout. The customer pages (orders, rewards,
                        addresses) are for customers — staff who want to
                        order use a personal customer account, which keeps
                        sales, points and the customer list clean. */}
                    {!showAdminLink && accountLinks.map(({ label, href, icon: Icon }) => (
                      <Link
                        key={href}
                        href={href}
                        role="menuitem"
                        onClick={() => setMenuOpen(false)}
                        className="flex items-center gap-3 rounded-[14px] px-3.5 py-2.5 font-sora text-[14px] text-black transition-colors hover:bg-black/[0.05]"
                      >
                        <Icon className="h-4 w-4 shrink-0" />
                        {label}
                      </Link>
                    ))}

                    {!showAdminLink && <span className="mx-3.5 my-1 block h-px bg-black/5" aria-hidden="true" />}

                    {showAdminLink && (
                      <Link
                        href={firstAllowedPath(role)}
                        role="menuitem"
                        onClick={() => setMenuOpen(false)}
                        className="flex items-center gap-3 rounded-[14px] px-3.5 py-3 font-sora text-[15px] text-black transition-colors hover:bg-black/[0.05]"
                      >
                        <LayoutDashboard className="h-4 w-4 shrink-0" />
                        {staffMenuLabel(role)}
                      </Link>
                    )}

                    <button
                      type="button"
                      role="menuitem"
                      onClick={() => {
                        setMenuOpen(false);
                        signOut({ callbackUrl: "/" });
                      }}
                      className="flex w-full items-center gap-3 rounded-[14px] px-3.5 py-3 text-left font-sora text-[15px] text-black transition-colors hover:bg-red-50 hover:text-red-600"
                    >
                      <LogOut className="h-4 w-4 shrink-0" />
                      Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <>
                <Link
                  href="/login"
                  className="hidden h-[46px] items-center justify-center rounded-full border border-black px-5 min-[420px]:flex font-sora text-[16px] font-semibold leading-[1.3] text-black transition-opacity hover:opacity-70 focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px]"
                >
                  Log In
                </Link>
                {/**
                  * ⚠️ `/register`, `/signup` নয় — পাতাটার ফোল্ডার
                  * `app/(auth)/register/`। ঠিক নিচের cart-এর মন্তব্যটার
                  * মতোই একই ভুল: বোতামের লেখা "Sign Up" দেখে path-টাও
                  * `/signup` ধরে নেওয়া হয়েছিল, আর সেটা সোজা 404-এ
                  * পাঠাত। AccountMenu আর login পাতা দুটোই আগে থেকেই
                  * `/register`-এ যেত, তাই ভুলটা কেবল এখানেই ছিল।
                  */}
                <Link
                  href="/register"
                  className="hidden h-[46px] items-center justify-center rounded-full bg-gradient-to-r from-[#FF9540] to-[#FF70C6] px-5 min-[640px]:flex font-sora text-[16px] font-semibold leading-[1.3] text-white transition-opacity hover:opacity-90 focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px]"
                >
                  Sign Up
                </Link>
              </>
            )}

            {/**
             * ⚠️ `/carts`, `/cart` নয় — পাতাটার ফোল্ডার
             * `app/(main)/carts/`। এক অক্ষরের ভুলে cart-এর আইকনটা
             * সোজা 404-এ নিয়ে যেত, অথচ "Add to cart" ঠিকই কাজ করছিল — 
             * তাই মনে হচ্ছিল cart-টাই ফাঁকা।
             */}
            <Link
              href="/carts"
              aria-label={
                cartCount > 0 ? `Cart, ${cartCount} items` : "Cart"
              }
              className="relative flex h-[42px] w-[42px] items-center justify-center rounded-full bg-black transition-opacity hover:opacity-90 focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px] min-[390px]:h-[46px] min-[390px]:w-[46px]"
            >
              <FaShoppingCart className="h-[18px] w-[18px] text-white" />
              {/* Badge only renders when there's actually something in the cart */}
              {cartCount > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#FF9540] px-1 font-sora text-[10px] font-semibold text-white">
                  {cartCount}
                </span>
              )}
            </Link>

            {/* Phone/tablet menu button — the page links don't fit in the
                row below 1024px (lg), so they live in this menu. */}
            <button
              type="button"
              onClick={() => {
                setMenuOpen(false);
                setMobileOpen((open) => !open);
              }}
              aria-label={mobileOpen ? "Close menu" : "Open menu"}
              aria-expanded={mobileOpen}
              aria-controls="site-mobile-menu"
              className="flex h-[42px] w-[42px] items-center justify-center rounded-full border border-black/15 bg-white text-black transition-colors hover:bg-black/[0.04] focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px] min-[390px]:h-[46px] min-[390px]:w-[46px] lg:hidden"
            >
              {mobileOpen ? <X className="h-5 w-5" aria-hidden="true" /> : <MenuIcon className="h-5 w-5" aria-hidden="true" />}
            </button>
          </div>
        
          {/* Phone/tablet menu panel */}
          {mobileOpen && (
            <nav
              id="site-mobile-menu"
              aria-label="Main"
              className="absolute left-0 right-0 top-full z-50 mt-3 flex flex-col gap-1 rounded-[20px] border border-black/5 bg-white p-2 shadow-[0_12px_32px_rgba(0,0,0,0.14)] lg:hidden"
            >
              {navLinks.map((link) => {
                const isActive = pathname === link.href;
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    aria-current={isActive ? "page" : undefined}
                    className={`rounded-[14px] px-4 py-3 font-sora text-[16px] transition-colors hover:bg-black/[0.05] ${
                      isActive ? "bg-[#F9F6F3] font-semibold text-[#141921]" : "text-black/75"
                    }`}
                  >
                    {link.label}
                  </Link>
                );
              })}
              {status !== "loading" && !session && (
                <div className="mt-1 grid grid-cols-2 gap-2 border-t border-black/5 p-2 pt-3 min-[640px]:hidden">
                  <Link
                    href="/login"
                    onClick={() => setMobileOpen(false)}
                    className="flex h-[46px] items-center justify-center rounded-full border border-black font-sora text-[15px] font-semibold text-black"
                  >
                    Log In
                  </Link>
                  <Link
                    href="/register"
                    onClick={() => setMobileOpen(false)}
                    className="flex h-[46px] items-center justify-center rounded-full bg-gradient-to-r from-[#FF9540] to-[#FF70C6] font-sora text-[15px] font-semibold text-white"
                  >
                    Sign Up
                  </Link>
                </div>
              )}
            </nav>
          )}
        </div>

        {/* Divider */}
        <span className="h-px w-full bg-black/10" aria-hidden="true" />
      </div>
    </header>
  );
}