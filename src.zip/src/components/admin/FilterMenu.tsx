"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";

/**
 * src/components/admin/FilterMenu.tsx
 *
 * Admin panel-এর ছাঁকনি dropdown — pill + popup, একটাই জায়গায়।
 *
 * ── কেন আলাদা component ────────────────────────────────────────────────
 *
 * Dashboard-এ তিনটে dropdown আছে: Recent Orders-এর period, Revenue
 * chart-এর range, Top Selling Items-এর range। তিনটেরই markup আর
 * class হুবহু এক ছিল, কিন্তু **কপি করা** — DashboardFilters-এ একবার,
 * RangeSelect-এ আরেকবার। ফলে একটার নকশা বদলালে অন্যটা নীরবে পিছিয়ে
 * থাকত, আর ঠিক সেটাই হয়েছিল: Users page-এর popup নতুন নকশায় গেছে,
 * dashboard-এরগুলো পুরনোতেই রয়ে গেছে।
 *
 * এখন popup-এর চেহারা এই একটা ফাইলেই। নতুন কোনো ছাঁকনি যোগ করলে
 * সেটা আপনা থেকেই মিলে যাবে।
 *
 * ⚠️ UsersToolbar.tsx-এ এই একই popup এখনো inline লেখা আছে। ওটাও এই
 * component-এ সরানো উচিত — তাহলে সত্যিই একটাই উৎস থাকে। এখন সরানো
 * হয়নি কারণ ওই পাতাটা চলছে আর ডেমো কাছে; কিন্তু ততদিন দুটো কপি
 * থাকছে, সেটা মনে রাখতে হবে।
 *
 * ── কী মেলানো হলো, কী মেলানো হয়নি ──────────────────────────────────────
 *
 * **popup** পুরোপুরি Users page-এর মতো: ২২৪px চওড়া, ভেতরে padding
 * 16, item-এর মাঝে gap 6, radius 16, ছায়া 0 4px 30px rgba(0,0,0,0.06),
 * কোনো ring নেই। বাছাই করা item-এর লেখা কমলা বা bold হয় না — সবার
 * লেখা #121212, কেবল তার পেছনে একটা cream (#F9F6F3) pill বসে।
 *
 * **pill (trigger)** dashboard-এর নিজের মাপেই থাকল: উচ্চতা 40, cream
 * পটভূমি, hug প্রস্থ। Users page-এর pill সাদা আর ১৫৬px স্থির, কারণ
 * ওটা cream পাতায় বসে; dashboard-এর pill বসে সাদা কার্ডে, তাই উল্টো
 * রঙ। দুটোকে এক করলে dashboard-এর pill কার্ডের সাথে মিশে গিয়ে
 * অদৃশ্য হয়ে যেত। অর্থাৎ পার্থক্যটা অসঙ্গতি নয়, পটভূমির ফল।
 */

/**
 * Focus চিহ্ন — UsersToolbar থেকে হুবহু।
 *
 * `ring-*` নয়, কারণ Tailwind-এর ring আসলে দুই স্তরের box-shadow, আর
 * প্রথম স্তরটা (`ring-offset-color`) ডিফল্টে সাদা। চওড়া শূন্য হলেও
 * ওই সাদাটা কিনারায় আধা-পিক্সেল থেকে যায় — cream pill-এর বাইরে
 * সেটা কমলার আগে একটা ফাঁক হয়ে ফুটে ওঠে।
 *
 * outline-এ ওই offset স্তরটাই নেই, আর ঋণাত্মক offset দিয়ে সেটা
 * কিনারার সামান্য ভেতরে আঁকা হয় — বাইরে ফাঁক জ্যামিতিকভাবেই অসম্ভব।
 *
 * শর্টহ্যান্ডের বদলে সরাসরি CSS, কারণ `outline` শর্টহ্যান্ড Tailwind
 * v3-এ width বোঝায় আর v4-এ style।
 *
 * `focus-visible`, `focus` নয় — mouse দিয়ে click করলে চিহ্নটা আসে না,
 * কেবল Tab চাপলে।
 */
export const FILTER_FOCUS_RING =
  "focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:-2px]";

export type FilterMenuOption<T extends string> = {
  value: T;
  /** popup-এর তালিকায় যা দেখাবে। */
  label: string;
  /**
   * pill-এ যা দেখাবে, যদি popup-এর নামটা লম্বা হয়। না দিলে `label`।
   * Users page-এ এভাবেই "Platinum Customer" pill-এ "Platinum" হয়।
   */
  triggerLabel?: string;
};

export default function FilterMenu<T extends string>({
  value,
  options,
  onSelect,
  ariaLabel,
  className = "",
  surface = "cream",
  triggerClassName,
  menuPositionClassName = "right-0",
}: {
  value: T;
  options: readonly FilterMenuOption<T>[];
  onSelect: (value: T) => void;
  /** screen reader-এর জন্য, যেমন "Period"। */
  ariaLabel?: string;
  /** বাইরের wrapper-এ বাড়তি class — যেমন RangeSelect-এর `ml-auto`। */
  className?: string;
  /**
   * pill-টা **কীসের উপরে** বসছে, তার রঙ নয়।
   *
   * ⚠️ ফাইলের শুরুর মন্তব্যে লেখা আছে কেন এটা দরকার: cream pill বসে
   * সাদা কার্ডে (dashboard, Overview), আর সাদা pill বসে cream পাতায়
   * (Users/Suppliers-এর toolbar, search ঘরের পাশে)। উল্টোটা করলে
   * pill পটভূমির সাথে মিশে গিয়ে কার্যত অদৃশ্য হয়ে যায় — ঠিক সেটাই
   * হচ্ছিল Suppliers toolbar-এ।
   *
   * prop-টার নাম `surface`, `variant` নয়, কারণ সিদ্ধান্তটা "কোন
   * চেহারা চাই" নয় — "নিচে কী আছে"। ওটা জানলে রঙ আপনাআপনি ঠিক হয়।
   */
  surface?: "cream" | "white";
  /**
   * trigger pill-টার নিজস্ব চেহারা — দিলে `surface`-এর মাপ আর রং
   * দুটোই এটা দিয়ে বদলে যায়।
   *
   * ⚠️ এটা যোগ করা হয়েছে reservation-এর অবস্থার ব্যাজের জন্য: ওটার রং
   * প্রতিটা সারিতে আলাদা (সবুজ Confirmed, লাল Cancelled), তাই দুটো
   * স্থির surface-এ কুলোয় না। আগে ওখানে native `<select>` ছিল, আর
   * browser তার option তালিকায় ব্যাজের সবুজ পটভূমিটাও টেনে আনত —
   * পুরো তালিকা সবুজের উপর সবুজ লেখা হয়ে যেত। এখন popup-টা বাকি
   * সিস্টেমের হুবহু একই সাদা তালিকা।
   */
  triggerClassName?: string;
  /**
   * popup কোন কিনারা ধরে ঝুলবে — ডিফল্ট `"right-0"` (button-এর ডান
   * কিনারার সাথে মিলিয়ে বাঁ দিকে ছড়ায়)।
   *
   * ⚠️ RangeSelect-এর `mobileStack` মোডে button-টা মোবাইলে বাঁ দিকে
   * বসে (title-এর নিচে, ডানে-ঠেলা `ml-auto` ছাড়া), তাই সেখানে
   * `"right-0"` ধরে রাখলে popup বাঁ দিকে ২২৪px ছড়িয়ে পর্দার বাইরে
   * চলে যেত। সেই ক্ষেত্রে RangeSelect responsive ক্লাস
   * (`"left-0 sm:right-0"`) পাঠায় — মোবাইলে বাঁ কিনারা ধরে ডানে
   * ছড়ায়, ≥৬৪০px-এ আবার আগের ডান-কিনারা আচরণে ফেরে।
   */
  menuPositionClassName?: string;
}) {
  const [open, setOpen] = useState(false);
  /**
   * তালিকাটা নিচে খুলবে না উপরে।
   *
   * ⚠️ পাতার শেষ দিকের সারিগুলোতে নিচে জায়গা থাকে না, আর তখন তালিকাটা
   * কার্ডের বাইরে বেরিয়ে পুরো পাতার উচ্চতা বাড়িয়ে দিত — ফলে ডান পাশে
   * একটা scrollbar এসে পড়ত আর তালিকার নিচের item-গুলো দেখতে scroll
   * করতে হতো।
   *
   * ⚠️ সিদ্ধান্তটা নেওয়া হয় খোলার ক্লিকে (নিচের `toggle`-এ), effect-এ
   * নয়। খোলার আগে জায়গা মাপলে প্রথম render-এই ঠিক দিকে খোলে, তাই
   * তালিকাটা এক ঝলকের জন্য নিচে দেখিয়ে তারপর উপরে লাফায় না।
   */
  const [dropUp, setDropUp] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onPointerDown = (event: MouseEvent) => {
      if (!dropdownRef.current?.contains(event.target as Node)) setOpen(false);
    };
    // Escape — keyboard user-এর বেরোনোর পথ। আগে এটা RangeSelect-এ ছিল
    // কিন্তু DashboardFilters-এ ছিল না; একসাথে আনায় সেটাও মিলে গেল।
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onPointerDown);
    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.removeEventListener("mousedown", onPointerDown);
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  /**
   * তালিকার আনুমানিক উচ্চতা: padding 32 + প্রতিটা item 34 + ফাঁক 6।
   *
   * ⚠️ আসল উচ্চতা মাপা যেত না — তালিকাটা তো এখনো render-ই হয়নি।
   * অনুমানটা একটু বেশি ধরা হয়েছে, কারণ ভুল হলে সবচেয়ে খারাপ যা হয়
   * তা হলো জায়গা থাকা সত্ত্বেও উপরে খোলা, যেটা ক্ষতিকর নয়।
   */
  const estimatedMenuHeight = 32 + options.length * 40;

  const toggle = () => {
    if (!open) {
      const rect = dropdownRef.current?.getBoundingClientRect();
      if (rect) {
        const spaceBelow = window.innerHeight - rect.bottom;
        const spaceAbove = rect.top;
        // নিচে না আঁটলে, আর উপরে বেশি জায়গা থাকলে — তবেই উপরে।
        setDropUp(spaceBelow < estimatedMenuHeight && spaceAbove > spaceBelow);
      }
    }
    setOpen((prev) => !prev);
  };

  // অজানা মান এলে (যেমন URL-এ হাতে লেখা ?period=xyz) প্রথমটায় পড়ে
  // থাকে, যাতে pill খালি না দেখায়।
  const selected = options.find((option) => option.value === value) ?? options[0];

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      {/* Figma Layout: Hug ×40, radius 100, padding 12, gap 8।
          লেখা Sora 400 14px #000000, icon 16×16।

          ⚠️ সাদা pill-টা Figma-তে ৫০ উঁচু আর padding 16 (toolbar-এর
          search ঘরের সমান), cream-টা ৪০ আর padding 12। উচ্চতাটা তাই
          surface-এর সাথেই বদলায় — নাহলে toolbar-এ ৪০px pill বসত
          ৫০px search ঘর আর ৫০px বোতামের মাঝখানে, আর সারিটা এবড়োখেবড়ো
          দেখাত। */}
      <button
        type="button"
        onClick={toggle}
        aria-expanded={open}
        aria-haspopup="listbox"
        aria-label={ariaLabel ? `${ariaLabel}: ${selected.label}` : undefined}
        /**
         * ⚠️ লেখার মাপটা আর শেয়ার্ড অংশে নেই, দুই surface-এ আলাদা করে
         * লেখা — ইচ্ছাকৃত। আগে বাইরে `text-[14px]` আর white-এর ভেতরে
         * `md:text-[16px]` ছিল; এখন white-এ ৩২০px-এর জন্য
         * `text-[12px]`-ও দরকার, আর একই class-তালিকায় দুটো
         * `text-[Npx]` রাখলে কোনটা জিতবে সেটা Tailwind-এর তৈরি
         * CSS-এর ক্রম ঠিক করে, class লেখার ক্রম নয় — অর্থাৎ ফলটা
         * অনুমান-নির্ভর। প্রতিটা শাখায় নিজের মাপ থাকলে সেই প্রশ্নই ওঠে না।
         *
         * ⚠️ white pill-টা ৪৮০-এর নিচে ৩৬px উঁচু, ৫০ নয় — Figma-র
         * ৩২০px frame-এ toolbar-এর তিনটে ঘরই (search, এই pill, "Add"
         * বোতাম) ৩৬×padding 12×লেখা 12px। ৫০px রাখলে দুটো pill
         * পাশাপাশি ২৮৮px-এ আঁটত না।
         */
        className={
          triggerClassName
            ? `flex items-center justify-center gap-2 whitespace-nowrap rounded-full font-sora leading-none transition-opacity hover:opacity-80 ${FILTER_FOCUS_RING} ${triggerClassName}`
            : `flex items-center gap-2 whitespace-nowrap rounded-full font-sora font-normal leading-none text-black transition-colors ${FILTER_FOCUS_RING} ${
                surface === "white"
                  ? "h-9 bg-white px-3 text-[12px] hover:bg-black/[0.03] min-[480px]:h-[50px] min-[480px]:px-4 min-[480px]:text-[14px] md:text-[16px]"
                  : "h-10 bg-[#F9F6F3] px-3 text-[14px] hover:bg-black/[0.06]"
              }`
        }
      >
        {selected.triggerLabel ?? selected.label}
        {/**
         * ⚠️ তীরটা কেবল white pill-এ ২০×২০, cream-এ আগের ১৬×১৬।
         * Figma-র toolbar frame-এ `vuesax/linear/arrow-down` ২০px, আর
         * সেটা ধরেই pill-এর প্রস্থ মেলে: 12+72+8+20+12 = 124, যা
         * frame-এর লেখা মাপের সমান। কার্ডের ভেতরের cream pill-গুলো
         * আলাদা frame থেকে আসে আর সেখানে ১৬ — তাই সবখানে এক করে
         * দেওয়া হয়নি।
         */}
        <ChevronDown
          className={`shrink-0 transition-transform ${
            surface === "white" && !triggerClassName ? "h-5 w-5" : "h-4 w-4"
          } ${open ? "rotate-180" : ""}`}
          strokeWidth={1.6}
          aria-hidden="true"
        />
      </button>

      {open && (
        /**
         * Figma "popup": column, padding 16, gap 6, চওড়া 224,
         * radius 16, BG #FFFFFF, shadow 0 4px 30px rgba(0,0,0,0.06)।
         *
         * ⚠️ ছায়াটা ইচ্ছাকৃতভাবে খুব নরম — ৩০px ছড়ানো, মাত্র ৬% ঘন।
         * Users page-এ popup-টা cream পাতার উপরে ভাসে, তাই সাদা-বনাম-
         * cream পার্থক্যটাই আলাদা করার কাজ করে আর ছায়ার দরকার পড়ে না।
         * Dashboard-এ কিন্তু popup বসে **সাদা কার্ডের উপরে** — সাদার
         * উপর সাদা, তাই কেবল এই ৬% ছায়াই আলাদা করে।
         *
         * বাস্তবে দেখে যদি চ্যাপ্টা লাগে, একটাই সংযোজন যথেষ্ট:
         * এই তালিকায় `ring-1 ring-black/5` যোগ করুন। নকশায় পাড় নেই,
         * তাই সেটা ইচ্ছাকৃত deviation হিসেবে লিখে রাখতে হবে।
         *
         * `max-w` শেষ রক্ষাকবচ: ৩২০px পর্দায় ২২৪px আঁটে, কিন্তু
         * ভবিষ্যতে কেউ আরও সরু জায়গায় বসালে যেন নীরবে উপচে না পড়ে।
         */
        <ul
          role="listbox"
          className={`absolute ${menuPositionClassName} z-20 flex w-[224px] max-w-[calc(100vw-48px)] flex-col gap-1.5 rounded-2xl bg-white p-4 shadow-[0_4px_30px_rgba(0,0,0,0.06)] ${
            dropUp ? "bottom-full mb-2" : "top-full mt-2"
          }`}
        >
          {options.map((option) => {
            const isSelected = option.value === selected.value;
            return (
              <li key={option.value} className="w-full">
                {/**
                 * Figma item: row, padding 10, উচ্চতা 34, লেখা
                 * Sora 400 14px LH 100% #121212।
                 *
                 * ⚠️ বাছাই করা item কমলা বা bold নয় — লেখার রঙ সবার
                 * এক, কেবল পেছনে cream pill। আগে dashboard-এ এটা
                 * `font-semibold text-[#FF4C15]` ছিল, যা নকশায় নেই।
                 *
                 * radius দুটো আলাদা, সেটাও ইচ্ছাকৃত: বাছাই করাটা 100
                 * (পুরো pill), বাকিরা 12। বাকিদের কোনো পটভূমিই নেই,
                 * তাই ওই ১২ কেবল hover-এর সময় চোখে পড়ে — designer
                 * সেই অবস্থাটার জন্যই মাপটা দিয়েছেন।
                 */}
                <button
                  type="button"
                  role="option"
                  aria-selected={isSelected}
                  onClick={() => {
                    setOpen(false);
                    onSelect(option.value);
                  }}
                  className={`flex h-[34px] w-full items-center gap-2 whitespace-nowrap p-2.5 text-left font-sora text-[14px] font-normal leading-none text-[#121212] transition-colors ${
                    isSelected
                      ? "rounded-full bg-[#F9F6F3]"
                      : "rounded-[12px] hover:bg-black/[0.04]"
                  }`}
                >
                  {option.label}
                </button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}