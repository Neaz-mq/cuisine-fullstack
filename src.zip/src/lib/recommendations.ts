// src/lib/recommendations.ts
import { prisma } from "@/lib/prisma";
import { type Money, toMoney } from "@/lib/money";

/**
 * ⚠️ `price` এখানে number, Decimal নয় — ইচ্ছাকৃতভাবে।
 *
 * এই type-টা /api/recommendations দিয়ে HTTP পেরিয়ে RecommendedForYou
 * (client component) পর্যন্ত যায়। JSON.stringify একটা Prisma Decimal-কে
 * string বানায় ("420"), object নয় — ফলে browser-এ `item.price.toFixed(2)`
 * চলত না, কারণ string-এ toFixed নেই। tsc কিছুই ধরত না, কারণ সে DB-র
 * ধরনটাই দেখত, তার নেটওয়ার্ক পেরোনোর পরের রূপ নয়।
 *
 * তাই রূপান্তরটা server-এ, sortByRank-এ — নিচের চারটে query-রই একমাত্র
 * পথ ওটা, তাই একটাও ফাঁক থাকে না। দাম এখানে শুধু দেখানো হয়, কোনো
 * হিসাব হয় না; আসল হিসাব order তৈরির সময় server-এ Decimal-এ।
 */
export interface RecommendedMenuItem {
  id: string;
  title: string;
  description: string;
  price: number;
  imageUrl: string | null;
}

/** Prisma যা দেয় — price এখনো Decimal। sortByRank-এ number-এ নামে। */
type MenuItemRow = Omit<RecommendedMenuItem, "price"> & { price: Money };

const MENU_ITEM_SELECT = {
  id: true,
  title: true,
  description: true,
  price: true,
  imageUrl: true,
} as const;

// Orders in these statuses represent real, completed activity — CANCELLED
// orders shouldn't influence "you might also like" or popularity ranking.
const COUNTED_ORDER_STATUSES = ["PLACED", "PREPARING", "OUT_FOR_DELIVERY", "DELIVERED"] as const;

// Sorts a MenuItem[] to match the ranking implied by an ordered id list —
// Prisma's `findMany({ where: { id: { in: [...] } } })` does NOT preserve
// the order of the ids you passed in, so every function below needs this.
//
// এখানেই Decimal -> number রূপান্তর হয়, কারণ প্রতিটা query শেষমেশ এই
// একটা function-এ এসে মেশে — উপরের interface-এর মন্তব্য দ্রষ্টব্য।
function sortByRank(items: MenuItemRow[], rankedIds: string[]): RecommendedMenuItem[] {
  const rank = new Map(rankedIds.map((id, i) => [id, i]));
  return [...items]
    .sort((a, b) => (rank.get(a.id) ?? 0) - (rank.get(b.id) ?? 0))
    .map((item) => ({ ...item, price: toMoney(item.price).toNumber() }));
}

/**
 * Best-selling items overall (by total quantity ordered), excluding any
 * ids passed in `excludeIds`. Used both as the guest/cold-start experience
 * and as a fallback wherever personalized data runs out.
 */
export async function getPopularItems(
  limit = 8,
  excludeIds: string[] = []
): Promise<RecommendedMenuItem[]> {
  const grouped = await prisma.orderItem.groupBy({
    by: ["menuItemId"],
    where: {
      order: { status: { in: [...COUNTED_ORDER_STATUSES] } },
      menuItemId: { notIn: excludeIds },
    },
    _sum: { quantity: true },
    orderBy: { _sum: { quantity: "desc" } },
    take: limit,
  });
  if (grouped.length === 0) return [];

  const rankedIds = grouped.map((g) => g.menuItemId);
  const items = await prisma.menuItem.findMany({
    where: { id: { in: rankedIds }, isAvailable: true },
    select: MENU_ITEM_SELECT,
  });
  return sortByRank(items, rankedIds);
}

/**
 * This customer's own most-ordered items — the "Order Again" row. Ranked
 * by total quantity they've personally ordered, most first.
 */
export async function getOrderAgainItems(
  userId: string,
  limit = 6
): Promise<RecommendedMenuItem[]> {
  const grouped = await prisma.orderItem.groupBy({
    by: ["menuItemId"],
    where: { order: { userId, status: { in: [...COUNTED_ORDER_STATUSES] } } },
    _sum: { quantity: true },
    orderBy: { _sum: { quantity: "desc" } },
    take: limit,
  });
  if (grouped.length === 0) return [];

  const rankedIds = grouped.map((g) => g.menuItemId);
  const items = await prisma.menuItem.findMany({
    where: { id: { in: rankedIds }, isAvailable: true },
    select: MENU_ITEM_SELECT,
  });
  return sortByRank(items, rankedIds);
}

/**
 * "You might also like" — item-item collaborative filtering: the same
 * "customers who ordered X also ordered Y" approach production
 * recommendation engines lean on before reaching for a full ML model.
 * Cheap to compute, fully explainable, and improves as order volume grows.
 *
 * 1. Look up everything this user has ordered.
 * 2. Find other customers ("neighbors") who ordered at least one of the
 *    same items — a rough proxy for "similar taste".
 * 3. Rank everything those neighbors ordered (that this user hasn't tried)
 *    by how often it co-occurs with this user's own items.
 */
export async function getYouMightAlsoLike(
  userId: string,
  limit = 8
): Promise<RecommendedMenuItem[]> {
  const ownItems = await prisma.orderItem.findMany({
    where: { order: { userId, status: { in: [...COUNTED_ORDER_STATUSES] } } },
    select: { menuItemId: true },
    distinct: ["menuItemId"],
  });
  const ownItemIds = ownItems.map((i) => i.menuItemId);
  if (ownItemIds.length === 0) return [];

  // Cap the fan-out for performance — this is a lightweight recommender,
  // not an offline batch job, so it runs on every relevant page load.
  const neighborOrders = await prisma.order.findMany({
    where: {
      userId: { not: userId },
      status: { in: [...COUNTED_ORDER_STATUSES] },
      items: { some: { menuItemId: { in: ownItemIds } } },
    },
    select: { items: { select: { menuItemId: true, quantity: true } } },
    take: 200,
  });

  const scores = new Map<string, number>();
  for (const order of neighborOrders) {
    for (const item of order.items) {
      if (ownItemIds.includes(item.menuItemId)) continue; // already a regular
      scores.set(item.menuItemId, (scores.get(item.menuItemId) ?? 0) + item.quantity);
    }
  }

  const rankedIds = [...scores.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([id]) => id);

  // Cold start within collaborative filtering (nobody else has ordered
  // this user's items yet, e.g. a brand-new restaurant) — fall back to
  // overall popularity, still excluding what they already order regularly.
  if (rankedIds.length === 0) {
    return getPopularItems(limit, ownItemIds);
  }

  const items = await prisma.menuItem.findMany({
    where: { id: { in: rankedIds }, isAvailable: true },
    select: MENU_ITEM_SELECT,
  });
  return sortByRank(items, rankedIds);
}

/**
 * "Pairs well with" — AI cart upsell. Given the menu item ids currently in
 * a customer's cart, suggest complementary items to add before checkout.
 *
 * Same item-item co-occurrence approach as getYouMightAlsoLike, but scoped
 * to *this cart* instead of a user's lifetime order history: look at every
 * past order that contains at least one of the cart items, then rank
 * whatever else showed up in those orders by how often it co-occurred.
 * Works for guests (no userId needed) and updates live as the cart changes.
 */
export async function getPairsWellWith(
  cartItemIds: string[],
  limit = 4
): Promise<RecommendedMenuItem[]> {
  const uniqueCartIds = [...new Set(cartItemIds)];
  if (uniqueCartIds.length === 0) return [];

  // Orders that included at least one of the cart's items — these are our
  // "neighbors" for co-occurrence, same cap as getYouMightAlsoLike so this
  // stays cheap enough to run on every cart change, not just page load.
  const coOrders = await prisma.order.findMany({
    where: {
      status: { in: [...COUNTED_ORDER_STATUSES] },
      items: { some: { menuItemId: { in: uniqueCartIds } } },
    },
    select: { items: { select: { menuItemId: true, quantity: true } } },
    take: 200,
  });

  const scores = new Map<string, number>();
  for (const order of coOrders) {
    for (const item of order.items) {
      if (uniqueCartIds.includes(item.menuItemId)) continue; // already in cart
      scores.set(item.menuItemId, (scores.get(item.menuItemId) ?? 0) + item.quantity);
    }
  }

  const rankedIds = [...scores.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([id]) => id);

  // Cold start (brand-new items with no order history yet to co-occur
  // from) — fall back to overall popularity, excluding the cart itself.
  if (rankedIds.length === 0) {
    return getPopularItems(limit, uniqueCartIds);
  }

  const items = await prisma.menuItem.findMany({
    where: { id: { in: rankedIds }, isAvailable: true },
    select: MENU_ITEM_SELECT,
  });
  return sortByRank(items, rankedIds);
}

export interface Recommendations {
  // false = "Popular Right Now" cold-start experience (guest, or a
  // customer with no qualifying order history yet). true = genuinely
  // personalized off this specific customer's own orders.
  personalized: boolean;
  orderAgain: RecommendedMenuItem[];
  recommended: RecommendedMenuItem[];
}

export async function getRecommendationsForUser(
  userId?: string | null
): Promise<Recommendations> {
  if (!userId) {
    return { personalized: false, orderAgain: [], recommended: await getPopularItems(8) };
  }

  const [orderAgain, youMightAlsoLike] = await Promise.all([
    getOrderAgainItems(userId, 6),
    getYouMightAlsoLike(userId, 8),
  ]);

  // Brand-new customer, no order history at all yet — still give them a
  // useful section instead of an empty one.
  if (orderAgain.length === 0 && youMightAlsoLike.length === 0) {
    return { personalized: false, orderAgain: [], recommended: await getPopularItems(8) };
  }

  return { personalized: true, orderAgain, recommended: youMightAlsoLike };
}