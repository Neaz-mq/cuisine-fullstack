import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { getRestaurantSettings } from "@/lib/get-settings";
import { formatAmount } from "@/lib/currency-format";
import { auth } from "@/auth";
import { displayPrice, findAllLiveOffers } from "@/lib/product-offers";
import MenuHero from "@/components/menu/MenuHero";
import TodaysOffers, { type MenuOffer } from "@/components/menu/TodaysOffers";
import MenuBrowser, { type MenuBrowserCategory } from "@/components/menu/MenuBrowser";
import MenuHighlights from "@/components/menu/MenuHighlights";
import { buildMenuHighlights } from "@/lib/menu-highlights";
import MenuComboCta from "@/components/menu/MenuComboCta";

export const metadata: Metadata = {
  title: "Menu",
  description: "Browse our full menu and order online for delivery or dine-in.",
};

/**
 * ⚠️ প্রতিটা request-এ নতুন করে render, build-এর সময় নয়।
 *
 * এটাই `(main)`-এর প্রথম **প্রকাশ্য** পাতা যেটা server-এ সরাসরি
 * database ছোঁয় (বাকিগুলো হয় স্থির, নয় client থেকে `/api/menu`
 * ডাকে)। Next.js ডিফল্টে এমন পাতা build-এর সময়ই একবার চালিয়ে HTML
 * বানিয়ে রাখতে চায় — আর CI-তে (GitHub Actions) কোনো database নেই,
 * তাই `prisma.restaurantSettings.upsert()` ECONNREFUSED দিয়ে পুরো
 * build ভেঙে দিত।
 *
 * ⚠️ `revalidate` দিয়ে সমাধান হতো না — ওটাতেও build-এর সময় একবার
 * render হয়, কেবল পরে নতুন করে হয়। ভাঙাটা ঠিক ওই প্রথম render-এই।
 *
 * Admin পাতাগুলোয় এই সমস্যা নেই, কারণ ওরা `requireStaff()` → `auth()`
 * → cookie পড়ে, আর cookie পড়া মানেই Next-এর কাছে পাতাটা এমনিতেই
 * dynamic।
 *
 * খরচ: প্রতিটা ভিজিটে কয়েকটা query। মেনু জিনিসটা ছোট, আর দাম বা
 * "পাওয়া যাচ্ছে না" অবস্থাটা বাসি দেখানোর চেয়ে সেটা অনেক সস্তা।
 */
export const dynamic = "force-dynamic";

/**
 * src/app/(main)/menu/page.tsx
 *
 * Figma "Web/Menu" — পাঁচটা অংশ, উপর থেকে নিচে:
 *
 *   1. Hero            #F9F6F3 — "Our Full Menu" pill + বড় শিরোনাম
 *   2. Today's Offers  সাদা — তিনটে রঙিন কুপন-কার্ড
 *   3. Categories      #F9F6F3 — chip + শ্রেণিভিত্তিক Food Card
 *   4. Chef's Picks    gradient — `MenuHighlights`: রেটিং / রান্নার সময় / প্রোটিন
 *   5. Combo CTA       সাদা — শিরোনাম + দুটো বোতাম
 *
 * উপরের কালো পটি, navbar আর Footer `(main)/layout.tsx`-এ — সব পাতায়
 * এক, তাই এখানে নেই।
 *
 * ⚠️ চতুর্থ অংশ আগে হোমপেজের `SignatureSection` ছিল — একই তিনটে কার্ড দুই
 * পাতায় দেখাত। এখন মেনু-পাতার নিজস্ব `MenuHighlights`: পটভূমি সেই একই
 * gradient, কিন্তু ভেতরে তিনটে তালিকা (Guest Favorites, Ready in a Flash,
 * Protein Packed)। কোনো নতুন query নেই — নিচে বানানো `categories` থেকেই
 * `buildMenuHighlights()` তালিকা বার করে (lib/menu-highlights.ts), তাই দাম
 * (অফার-সহ), রেটিং, সময় মেনু-তালিকার সাথে হুবহু মেলে।
 * `SignatureSection` আর `getSignatureDishes()` এখন শুধু হোমপেজে।
 *
 * ⚠️ পঞ্চম অংশটা কিন্তু `landing/ComboSection` **নয়**, যদিও শিরোনাম
 * প্রায় এক। ওটা তিনটে combo কার্ড সহ আস্ত একটা section, এটা কেবল
 * শিরোনাম + দুটো বোতাম। বিস্তারিত MenuComboCta.tsx-এ।
 *
 * ⚠️ পুরনো পাঁচটা component (`Explore`, `RecommendedForYou`, `Items`,
 * `Weekly`, `Delights`) আর ব্যবহার হয় না। মুছিনি — যাচাই করে মুছবেন:
 *
 *     grep -rn "components/Explore\|components/Items\|components/Weekly" src/
 *
 * `Delights` আর `RecommendedForYou` অন্য পাতায় থাকতে পারে, তাই
 * আন্দাজে মোছা নয়।
 */
export default async function MenuPage() {
  const now = new Date();

  /**
   * ⚠️ তিনটে query, তিনটে আলাদা জিনিসের জন্য — কিন্তু একসাথে চালানো
   * হয় (`Promise.all`), ধারাবাহিকভাবে নয়। কোনোটা অন্যটার ফলের উপর
   * নির্ভর করে না, তাই পরপর `await` করলে শুধু অপেক্ষার সময়টাই যোগ হতো।
   */
  const [settings, categoryRows, ratingRows, couponRows, liveOffers, session] = await Promise.all([
    getRestaurantSettings(),
    prisma.category.findMany({
      orderBy: [{ sortOrder: "asc" }, { name: "asc" }],
      select: {
        id: true,
        name: true,
        menuItems: {
          // পাওয়া যাচ্ছে এমনগুলো আগে, তারপর নাম ধরে — নাহলে "All"
          // দৃশ্যে প্রতিটা শ্রেণির প্রথম তিনটেই বন্ধ পদ হয়ে যেতে পারত।
          orderBy: [{ isAvailable: "desc" }, { title: "asc" }],
          select: {
            id: true,
            title: true,
            description: true,
            price: true,
            imageUrl: true,
            isAvailable: true,
            calories: true,
            fatGrams: true,
            proteinGrams: true,
            prepTimeMinutes: true,
          },
        },
      },
    }),

    /**
     * প্রতিটা পদের গড় রেটিং — কেবল **অনুমোদিত** review থেকে।
     *
     * ⚠️ `groupBy`, প্রতিটা পদের সাথে relation নয়। relation-এ আনলে
     * প্রতিটা পদের সব review-র সারি টানতে হতো শুধু একটা গড় বার করতে,
     * অথচ DB নিজেই সেটা করতে পারে।
     */
    prisma.review.groupBy({
      by: ["menuItemId"],
      where: { status: "APPROVED" },
      _avg: { rating: true },
    }),

    prisma.coupon.findMany({
      where: {
        isActive: true,
        AND: [
          { OR: [{ startsAt: null }, { startsAt: { lte: now } }] },
          { OR: [{ expiresAt: null }, { expiresAt: { gt: now } }] },
        ],
      },
      orderBy: { createdAt: "desc" },
      /**
       * ⚠️ এই তালিকাটা **দুই কাজে** লাগে: উপরের "Today's Offers"-এর
       * তিনটে কার্ড, আর প্রতিটা পদের ছবির কোণে ছাড়ের ব্যাজ। তাই
       * তিনটের বেশি আনা হয় — ব্যাজের জন্য সবগুলো চালু কুপনই দেখা
       * দরকার, নাহলে চার নম্বর কুপনটা কোনো পদে বসত না।
       */
      take: 50,
      select: {
        id: true,
        code: true,
        type: true,
        percentOff: true,
        fixedOff: true,
        minOrderValue: true,
        expiresAt: true,
        usageLimit: true,
        usageCount: true,
        // The card text staff write in /admin/coupons (optional).
        label: true,
        headline: true,
        description: true,
        restrictedCategories: { select: { id: true, name: true } },
        restrictedItems: { select: { id: true } },
      },
    }),

    // ⚠️ আগে এই দুটো (offer, session) উপরের query-গুলোর **পরে** চলত — কারণ
    // offer-এর query-তে পদের id লাগত। এখন সব চালু offer একসাথে আনা হয়
    // (সংখ্যায় অল্প), তাই পুরো পাতার database কাজ এক ধাপে: settings,
    // মেনু, রেটিং, কুপন, offer, আর session সবাই সমান্তরালে। আগে ছিল
    // তিন ধাপ = তিনটে পুরো network round-trip।
    findAllLiveOffers(now),
    auth(),
  ]);
  const units = settings.currencyMinorUnits;

  const ratingByItem = new Map(
    ratingRows.map((row) => [row.menuItemId, row._avg.rating])
  );

  // Product offers (/admin/offers): the price shown here is the price
  // checkout charges. Members-only offers need to know who is looking.
  const isMember = Boolean(session?.user?.id);

  // ব্যবহারের সীমা পেরোনো কুপন কোথাও দেখানো হয় না — কার্ডেও না,
  // ব্যাজেও না। এটা JS-এ, কারণ Prisma-য় এক কলামের সাথে আরেক কলামের
  // তুলনা (`usageCount < usageLimit`) raw SQL ছাড়া লেখা যায় না, আর
  // কুপনের সংখ্যা এমনিতেই হাতে গোনা।
  const liveCoupons = couponRows.filter(
    (coupon) => coupon.usageLimit === null || coupon.usageCount < coupon.usageLimit
  );

  /**
   * ── ছবির কোণের ছাড়ের ব্যাজ ────────────────────────────────────────
   *
   * ⚠️ কেবল সেই কুপনগুলো, যেগুলো কোনো **নির্দিষ্ট** পদ বা শ্রেণির জন্য।
   * সাইট-জোড়া কুপন ধরলে প্রতিটা কার্ডেই ব্যাজ বসত, অথচ সেটা উপরের
   * "Today's Offers"-এ এমনিতেই দেখা যাচ্ছে — তখন ব্যাজটা তথ্য নয়,
   * গোলমাল।
   *
   * ⚠️ একাধিক কুপন মিললে সবচেয়ে বড়টা — আর তুলনাটা **এই পদের দামের
   * উপরে টাকার অঙ্কে**, শতাংশে নয়। "১০%" আর "$৫ ছাড়" সরাসরি তুলনা
   * করা যায় না: $২০-র পদে ১০% মানে $২, কিন্তু $১০০-র পদে $১০।
   */
  const targetedCoupons = liveCoupons.filter(
    (coupon) =>
      coupon.restrictedItems.length > 0 || coupon.restrictedCategories.length > 0
  );

  const discountFor = (itemId: string, categoryId: string, price: number) => {
    let bestValue = 0;
    let bestLabel: string | null = null;

    for (const coupon of targetedCoupons) {
      const applies =
        coupon.restrictedItems.some((item) => item.id === itemId) ||
        coupon.restrictedCategories.some((category) => category.id === categoryId);
      if (!applies) continue;

      if (coupon.type === "PERCENT" && coupon.percentOff !== null) {
        const value = (price * coupon.percentOff) / 100;
        if (value > bestValue) {
          bestValue = value;
          bestLabel = `${coupon.percentOff}%`;
        }
      } else if (coupon.fixedOff !== null) {
        // দামের চেয়ে বড় ছাড় হয় না — $২০ ছাড়ের কুপন $৫-এর পদে
        // বসলে "$২০ Off" লেখাটা অর্থহীন হতো।
        const value = Math.min(Number(coupon.fixedOff), price);
        if (value > bestValue) {
          bestValue = value;
          bestLabel = `${formatAmount(value.toFixed(units), settings.currency)} Off`;
        }
      }
    }

    return bestLabel;
  };

  /**
   * DB-র সারি → client component যা বোঝে সেই আকার।
   *
   * ⚠️ `price` `Number()` করা বাধ্যতামূলক: Prisma-র `Decimal` সরল
   * object নয়, তাই server component থেকে client-এ পাঠালে Next.js
   * throw করে ("Only plain objects can be passed to Client
   * Components")। দামের **লেখা** রূপটাও এখানেই তৈরি — `formatAmount`
   * মুদ্রার minor unit জানে, আর সেটা RestaurantSettings-এ, অর্থাৎ
   * server-এ।
   */
  const categories: MenuBrowserCategory[] = categoryRows
    .filter((row) => row.menuItems.length > 0)
    .map((row) => ({
      id: row.id,
      name: row.name,
      items: row.menuItems.map((item) => {
        const shown = displayPrice(
          item.price,
          liveOffers.get(item.id),
          isMember,
          settings.currency,
          units
        );
        const price = shown.price;
        const average = ratingByItem.get(item.id);

        return {
          id: item.id,
          title: item.title,
          description: item.description,
          price,
          priceLabel: shown.priceLabel,
          oldPriceLabel: shown.oldPriceLabel,
          imageUrl: item.imageUrl,
          isAvailable: item.isAvailable,
          calories: item.calories,
          fatGrams: item.fatGrams,
          proteinGrams: item.proteinGrams,
          prepTimeMinutes: item.prepTimeMinutes,
          // `_avg` কোনো review না থাকলে `null` দেয় — সেটাই এখানে
          // "রেটিং দেখানো হবে না"-র সংকেত।
          rating: average ?? null,
          // A product offer's own badge first; otherwise a coupon aimed at
          // this dish or its category.
          discountLabel: shown.badge ?? discountFor(item.id, row.id, price),
        };
      }),
    }));

  /**
   * কুপন → কার্ডের লেখা।
   *
   * ⚠️ প্রতিটা বাক্য DB-র মান থেকে বানানো, কোনো marketing copy হাতে
   * লেখা নেই — কারণ `Coupon`-এ ওরকম কোনো মাঠই নেই। পুরো যুক্তিটা
   * TodaysOffers.tsx-এর মাথায়।
   */
  const offers: MenuOffer[] = liveCoupons
    // নকশায় তিনটে কার্ড, তাই তিনটেই।
    .slice(0, 3)
    .map((coupon) => {
      const discount =
        coupon.type === "FREE_DELIVERY"
          ? "Free Delivery On"
          : coupon.type === "PERCENT" && coupon.percentOff !== null
            ? `${coupon.percentOff}% Off`
            : coupon.fixedOff !== null
              ? `${formatAmount(Number(coupon.fixedOff).toFixed(units), settings.currency)} Off`
              : "A Discount";

      const scope =
        coupon.restrictedCategories.length > 0
          ? coupon.restrictedCategories.map((category) => category.name).join(", ")
          : "Every Order";

      const conditions = [`Use code ${coupon.code} at checkout`];
      if (coupon.minOrderValue !== null) {
        conditions.push(
          `on orders over ${formatAmount(
            Number(coupon.minOrderValue).toFixed(units),
            settings.currency
          )}`
        );
      }

      let detail = `${conditions.join(" ")}.`;
      if (coupon.expiresAt) {
        // দিন-মাস, বছর নয় — কুপন সাধারণত কয়েক সপ্তাহের, আর "2026"
        // লেখাটা কার্ডে অকারণ জায়গা নিত।
        detail += ` Ends ${coupon.expiresAt.toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
        })}.`;
      }

      // Staff-written text (/admin/coupons) wins; the built sentences are
      // the fallback for coupons that don't have any.
      return {
        id: coupon.id,
        code: coupon.code,
        eyebrow: coupon.label?.trim() || scope,
        headline: coupon.headline?.trim() || `${discount} Your Order`,
        detail: coupon.description?.trim() || detail,
      };
    });

  // "Chef's Picks" — উপরের `categories` থেকেই, আলাদা query ছাড়া।
  const highlights = buildMenuHighlights(categories);

  return (
    <>
      <MenuHero />
      <TodaysOffers offers={offers} />
      {/* ⚠️ রান্নাঘরের সময়ের prop গুলো আর নেই — "Order Now" এখন cart-এ
          যোগ করে না, পদটার নিজের পাতায় নিয়ে যায়। যোগ করার কাজটা
          ওখানে (ProductDetail.tsx), আর সেখানেই ওই যাচাইটার কথা
          লেখা আছে। */}
      <MenuBrowser categories={categories} />
      <MenuHighlights groups={highlights} />
      <MenuComboCta />
    </>
  );
}