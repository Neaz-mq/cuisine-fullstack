"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { toast } from "react-toastify";

/**
 * src/app/(main)/track/[orderId]/OrderCelebration.tsx
 *
 * অর্ডার পৌঁছে যাওয়ার পর Figma-র দুটো modal, একটার পর একটা:
 *
 *   ১. "Congratulations!"  — 555px, radius 30, padding 30, gap 31
 *      বোতাম: "Go to Home" (কালো outline) · "Food Review" (gradient)
 *   ২. "How Was Your Food Experience?" — 815px, radius 20, padding 60/30
 *      90px cream গোলে কমলা তারা, textarea, "Skip" · "Submit"
 *
 * ⚠️ দুটো আলাদা `<dialog>` নয়, একটাই — শুধু ভেতরের content বদলায়।
 * দুটো dialog একসাথে থাকলে প্রথমটা বন্ধ করে দ্বিতীয়টা খোলার মাঝে এক
 * মুহূর্তের জন্য focus পর্দার কোথাও থাকত না, আর screen reader পুরো
 * প্রসঙ্গটাই হারাত।
 *
 * ── কখন দেখা যায় ────────────────────────────────────────────────────
 *
 * ⚠️ অর্ডারপ্রতি একবার, আর সেটা মনে রাখা হয় localStorage-এ। DB-তে
 * রাখা যেত, কিন্তু তাতে প্রতিটা /track লোডে একটা বাড়তি query লাগত
 * শুধু "এই উৎসবটা কি আগে দেখানো হয়েছে" জানতে — অথচ ভুল হলে সবচেয়ে
 * খারাপ যা হয় তা হলো গ্রাহক অন্য ব্রাউজারে আরেকবার অভিনন্দন দেখেন।
 *
 * ⚠️ localStorage সব পরিবেশে থাকে না (private mode, storage বন্ধ করা
 * ব্রাউজার), তাই প্রতিটা ডাক try/catch-এ। ব্যর্থ হলে আচরণ হয় "মনে নেই"
 * — modal আবার দেখাবে, কিন্তু পাতা ভাঙবে না।
 */

const SEEN_KEY = (orderId: string) => `order-celebrated:${orderId}`;

export function hasSeenCelebration(orderId: string): boolean {
  try {
    return window.localStorage.getItem(SEEN_KEY(orderId)) === "1";
  } catch {
    return false;
  }
}

function rememberCelebration(orderId: string) {
  try {
    window.localStorage.setItem(SEEN_KEY(orderId), "1");
  } catch {
    // storage বন্ধ — পরের বার আবার দেখাবে, সেটাই সবচেয়ে খারাপ ফল।
  }
}

export type CelebrationStep = "congrats" | "review";
type Step = CelebrationStep;

/** One dish in the order, for the "rate your dishes" list. */
export type ReviewDish = { menuItemId: string; title: string; imageUrl: string | null };

export default function OrderCelebration({
  open,
  orderId,
  onClose,
  dishes = [],
  canRate = false,
  riderName = null,
  riderImage = null,
  startAt = "congrats",
}: {
  open: boolean;
  orderId: string;
  onClose: () => void;
  /** The dishes in this order (one entry per dish). */
  dishes?: ReviewDish[];
  /**
   * Star ratings need a logged-in customer who owns the order (see
   * /api/orders/[id]/review). Guests only get the comment box.
   */
  canRate?: boolean;
  /** Our own rider delivered it and hasn't been rated yet → "Rate your
   *  rider" stars (guests too — they are the customer). */
  riderName?: string | null;
  /** The rider's profile photo, shown beside their name. Null → initial. */
  riderImage?: string | null;
  /** "review" when opened from the "Write a Review" button — skips the
   *  congratulations screen the customer has already seen. */
  startAt?: Step;
}) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [step, setStep] = useState<Step>(startAt);
  const [comment, setComment] = useState("");
  // menuItemId → 1..5. A dish with no entry simply isn't rated.
  const [ratings, setRatings] = useState<Record<string, number>>({});
  const [riderRating, setRiderRating] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  // Each time the dialog opens, start on the requested screen. (Adjusting
  // state during render, like MenuToolbar does, instead of in an effect.)
  const [wasOpen, setWasOpen] = useState(open);
  if (open !== wasOpen) {
    setWasOpen(open);
    if (open) setStep(startAt);
  }

  const ratedCount = Object.keys(ratings).length;
  const canSubmit = comment.trim().length > 0 || ratedCount > 0 || riderRating > 0;

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  /**
   * Esc-এ browser নিজেই dialog বন্ধ করে, কিন্তু React-এর state সেটা
   * জানে না — `close` event ধরে মিলিয়ে না দিলে state আর DOM আলাদা হয়ে
   * যেত আর modal-টা আর কখনো খুলত না।
   */
  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    const handleClose = () => {
      rememberCelebration(orderId);
      onClose();
    };
    dialog.addEventListener("close", handleClose);
    return () => dialog.removeEventListener("close", handleClose);
  }, [orderId, onClose]);

  function dismiss() {
    rememberCelebration(orderId);
    onClose();
  }

  async function submitReview() {
    const text = comment.trim();
    if (!canSubmit || submitting) return;

    setSubmitting(true);
    try {
      const res = await fetch(`/api/orders/${orderId}/review`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          comment: text,
          ratings: Object.entries(ratings).map(([menuItemId, rating]) => ({ menuItemId, rating })),
          ...(riderName && riderRating > 0 ? { riderRating } : {}),
        }),
      });

      if (!res.ok) {
        // ⚠️ server-এর নিজের বার্তাটাই দেখানো হয় — "আগে ডেলিভারি হতে
        // হবে" বা "খুব বেশি চেষ্টা" জাতীয় কারণগুলো ওখান থেকেই আসে, আর
        // সেগুলো ছাড়া গ্রাহক বুঝতেই পারতেন না কী হলো।
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error ?? "Couldn't send your review.");
      }

      toast.success("Thanks for your review!");
      dismiss();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Couldn't send your review.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <dialog
      ref={dialogRef}
      aria-labelledby={`celebration-title-${orderId}`}
      onClick={(event) => {
        if (event.target === dialogRef.current) dismiss();
      }}
      className={`m-auto max-h-[calc(100dvh-32px)] w-[calc(100vw-32px)] overflow-y-auto bg-white p-0 backdrop:bg-black/50 ${
        step === "congrats" ? "max-w-[555px] rounded-[30px]" : "max-w-[815px] rounded-[20px]"
      }`}
    >
      {step === "congrats" ? (
        <div className="flex flex-col items-center gap-6 p-6 text-center md:gap-[31px] md:p-[30px]">
          <CelebrationArt />

          <div className="flex flex-col items-center gap-5">
            <h2
              id={`celebration-title-${orderId}`}
              className="font-frank-ruhl text-[32px] font-semibold leading-[1.14] tracking-[-0.01em] text-black md:text-[46px]"
            >
              Congratulations!
            </h2>
            <p className="max-w-[495px] font-sora text-[14px] leading-[1.6] text-black/70 md:text-[16px]">
              Thank you for your order. We look forward to welcoming you again with fresh flavors.
            </p>
          </div>

          <div className="flex w-full flex-col gap-3 min-[420px]:flex-row">
            {/* ⚠️ `<Link>`, বোতাম নয় — এটা সত্যিই একটা navigation, তাই
                মাঝ-ক্লিক বা নতুন ট্যাবে খোলা কাজ করা উচিত। */}
            <Link
              href="/"
              onClick={dismiss}
              className="flex h-[46px] shrink-0 min-[420px]:flex-1 items-center justify-center rounded-full border border-black px-5 font-sora text-[15px] font-semibold leading-none text-black transition-colors hover:bg-black hover:text-white focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px] md:text-[16px]"
            >
              Go to Home
            </Link>
            <button
              type="button"
              onClick={() => setStep("review")}
              className="flex h-[46px] shrink-0 min-[420px]:flex-1 items-center justify-center rounded-full bg-[linear-gradient(93.36deg,#FF9540_0%,#FF70C6_145.78%)] px-5 font-sora text-[15px] font-semibold leading-none text-white transition-opacity hover:opacity-90 focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px] md:text-[16px]"
            >
              Food Review
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-6 px-5 py-10 md:gap-[30px] md:px-[30px] md:py-[60px]">
          <div className="flex w-full max-w-[579px] flex-col items-center gap-6">
            <div className="flex flex-col items-center gap-[30px]">
              {/* Figma "Frame 2147236204": 90px cream গোল, ভেতরে 44px তারা। */}
              <span className="flex h-[70px] w-[70px] items-center justify-center rounded-full bg-[#F9F6F3] md:h-[90px] md:w-[90px]">
                <svg
                  className="h-9 w-9 md:h-11 md:w-11"
                  viewBox="0 0 24 24"
                  fill="#FF9540"
                  aria-hidden="true"
                >
                  <path d="M12 2.5l2.9 5.88 6.49.95-4.7 4.58 1.11 6.46L12 17.33l-5.8 3.05 1.1-6.46-4.69-4.58 6.49-.95L12 2.5Z" />
                </svg>
              </span>

              <div className="flex flex-col items-center gap-3 text-center">
                <h2
                  id={`celebration-title-${orderId}`}
                  className="font-frank-ruhl text-[24px] font-medium leading-[1.2] text-[#121212] md:text-[30px]"
                >
                  How Was Your Food Experience?
                </h2>
                <p className="max-w-[433px] font-sora text-[13px] leading-[1.5] text-[#121212]/60 md:text-[14px]">
                  Tell us what you loved about your meal. Your review helps other food lovers
                  discover our best dishes.
                </p>
              </div>
            </div>

            {canRate && dishes.length > 0 && (
              <DishRatings
                dishes={dishes}
                ratings={ratings}
                onRate={(menuItemId, rating) =>
                  setRatings((prev) => ({ ...prev, [menuItemId]: rating }))
                }
              />
            )}

            {riderName && (
              <DishRatings
                heading="Rate your rider"
                dishes={[{ menuItemId: "rider", title: `${riderName} · your delivery rider`, imageUrl: riderImage }]}
                ratings={{ rider: riderRating }}
                onRate={(_id, rating) => setRiderRating(rating)}
              />
            )}

            {/* Figma "Fill": cream, radius 12, padding 12, উচ্চতা 121। */}
            <textarea
              value={comment}
              onChange={(event) => setComment(event.target.value)}
              maxLength={2000}
              rows={4}
              aria-label="Your food experience"
              placeholder="Type here your food experience...."
              className="h-[121px] w-full resize-none rounded-[12px] bg-[#F9F6F3] p-3 font-sora text-[13px] leading-[1.6] text-black placeholder:text-black/70 focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:-2px] md:text-[14px]"
            />

            <div className="flex w-full max-w-[333px] flex-col gap-2 min-[420px]:flex-row">
              <button
                type="button"
                onClick={dismiss}
                className="flex h-[46px] shrink-0 min-[420px]:flex-1 items-center justify-center rounded-full border border-black px-5 font-sora text-[15px] font-semibold leading-none text-black transition-colors hover:bg-black hover:text-white focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px] md:text-[16px]"
              >
                Skip
              </button>
              <button
                type="button"
                onClick={submitReview}
                /* ⚠️ ফাঁকা লেখায় নিষ্ক্রিয় — server-ও সেটা নেবে না
                   (orderReviewSchema), তাই এখানে আটকানো মানে একটা অকারণ
                   round trip আর একটা error toast কম। */
                disabled={submitting || !canSubmit}
                className="flex h-[46px] shrink-0 min-[420px]:flex-1 items-center justify-center rounded-full bg-[linear-gradient(93.36deg,#FF9540_0%,#FF70C6_145.78%)] px-5 font-sora text-[15px] font-semibold leading-none text-white transition-opacity hover:opacity-90 focus:outline-none focus-visible:[outline:2px_solid_#FF9540] focus-visible:[outline-offset:2px] disabled:opacity-50 md:text-[16px]"
              >
                {submitting ? "Sending…" : "Submit"}
              </button>
            </div>
          </div>
        </div>
      )}
    </dialog>
  );
}

/**
 * Figma "Frame 2147225766" — কমলা টিক-চিহ্ন আর চারপাশে confetti।
 *
 * ⚠️ ছবি নয়, inline SVG: আকারটা সরল (গোল, তারা, কয়েকটা রেখা) আর
 * তাতে কোনো নেটওয়ার্ক request লাগে না — modal-টা ঠিক যে মুহূর্তে
 * খোলে সেই মুহূর্তেই পুরোটা দেখা যায়, অর্ধেক আঁকা অবস্থায় নয়।
 */
/**
 * "Rate your dishes" — one row per dish: photo, name, five stars.
 *
 * Each row is a radio group, so screen readers announce "3 of 5" and the
 * arrow keys work. Tapping the star that is already chosen keeps it (there
 * is no un-rate — just don't touch a dish you don't want to rate).
 */
function DishRatings({
  heading = "Rate your dishes",
  dishes,
  ratings,
  onRate,
}: {
  heading?: string;
  dishes: ReviewDish[];
  ratings: Record<string, number>;
  onRate: (menuItemId: string, rating: number) => void;
}) {
  return (
    <div className="flex w-full flex-col gap-3">
      <p className="font-sora text-[13px] font-semibold leading-none text-black md:text-[14px]">
        {heading}
      </p>
      <ul className="flex w-full flex-col gap-2">
        {dishes.map((dish) => {
          const current = ratings[dish.menuItemId] ?? 0;
          return (
            <li
              key={dish.menuItemId}
              className="flex flex-col gap-2 rounded-[12px] bg-[#F9F6F3] p-3 min-[420px]:flex-row min-[420px]:items-center min-[420px]:justify-between"
            >
              <span className="flex min-w-0 items-center gap-3">
                {/* ⚠️ রাইডারের ছবি গোল (মানুষ), খাবারের ছবি গোলাকার-চৌকো। আর
                    `referrerPolicy="no-referrer"` লাগে: রাইডারের ছবি প্রায়ই
                    Google-এর avatar (lh3.googleusercontent.com), যেটা Referer
                    পেলে অনেক সময় ছবি না দিয়ে খালি ফেরায়। ছবি না থাকলে বা
                    লোড না হলে নামের প্রথম অক্ষর — আগের মতো ফাঁকা সাদা বাক্স নয়। */}
                {dish.imageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element -- small thumbnail from any allowed host
                  <img
                    src={dish.imageUrl}
                    alt=""
                    width={40}
                    height={40}
                    referrerPolicy="no-referrer"
                    className={`h-10 w-10 shrink-0 object-cover ${
                      dish.menuItemId === "rider" ? "rounded-full" : "rounded-[8px]"
                    }`}
                  />
                ) : dish.menuItemId === "rider" ? (
                  <span
                    aria-hidden="true"
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-white font-frank-ruhl text-[18px] font-semibold text-black/70"
                  >
                    {dish.title.charAt(0).toUpperCase()}
                  </span>
                ) : (
                  <span aria-hidden="true" className="h-10 w-10 shrink-0 rounded-[8px] bg-white" />
                )}
                <span className="min-w-0 break-words font-sora text-[13px] font-medium leading-[1.3] text-black md:text-[14px]">
                  {dish.title}
                </span>
              </span>

              <div
                role="radiogroup"
                aria-label={`Rate ${dish.title}`}
                className="flex shrink-0 items-center gap-0.5"
              >
                {[1, 2, 3, 4, 5].map((value) => (
                  <button
                    key={value}
                    type="button"
                    role="radio"
                    aria-checked={current === value}
                    aria-label={`${value} star${value === 1 ? "" : "s"}`}
                    onClick={() => onRate(dish.menuItemId, value)}
                    className="flex h-9 w-9 items-center justify-center rounded-full transition-transform hover:scale-110 focus:outline-none focus-visible:[outline:2px_solid_#FF9540]"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      className="h-6 w-6"
                      fill={value <= current ? "#FF9540" : "none"}
                      stroke="#FF9540"
                      strokeWidth={1.5}
                      strokeLinejoin="round"
                      aria-hidden="true"
                    >
                      <path d="M12 2.5l2.9 5.88 6.49.95-4.7 4.58 1.11 6.46L12 17.33l-5.8 3.05 1.1-6.46-4.69-4.58 6.49-.95L12 2.5Z" />
                    </svg>
                  </button>
                ))}
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function CelebrationArt() {
  return (
    <svg
      viewBox="0 0 315 269"
      className="h-[180px] w-[210px] md:h-[268px] md:w-[315px]"
      fill="none"
      aria-hidden="true"
    >
      <circle cx="160" cy="171" r="97" fill="#FEF0E3" />

      {/**
        * Figma "Polygon 17" — ৯ কোণার rosette (153.87px বাক্সে
        * border-radius 37.68)। নিজের 200×200 ছকে আঁকা, তাই নিচে
        * translate + scale দিয়ে cream গোলটার কেন্দ্রে বসানো হয়েছে;
        * এতে path-টা দুই ফাইলে (এখানে আর Carts-এর success modal)
        * হুবহু এক থাকে।
        */}
      <g transform="translate(160 171) scale(0.77) translate(-100 -100)">
        <path
          d="M173.8 109.6 A38.2 38.2 0 0 1 165.9 134.5 L150.4 154.8 A38.2 38.2 0 0 1 128.3 168.8 L103.4 174.3 A38.2 38.2 0 0 1 77.5 170.9 L54.8 159.1 A38.2 38.2 0 0 1 37.2 139.8 L27.4 116.2 A38.2 38.2 0 0 1 26.3 90.1 L33.9 65.8 A38.2 38.2 0 0 1 49.8 45.0 L71.4 31.3 A38.2 38.2 0 0 1 96.9 25.7 L122.2 29.0 A38.2 38.2 0 0 1 145.4 41.1 L162.7 59.9 A38.2 38.2 0 0 1 172.7 84.0 Z"
          fill="#FFFFFF"
          stroke="#FA7F12"
          strokeWidth="12.2"
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        <path
          d="M74 101l18 19 34-38"
          fill="none"
          stroke="#FA7F12"
          strokeWidth="12.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>

      {/* confetti — কমলা #FA7F12, গোলাপি #FF70C6 */}
      <path
        d="M54 39c8-12 20-14 27-6s18 6 27-6"
        stroke="#FF5E07"
        strokeWidth="4.7"
        strokeLinecap="round"
      />
      <path
        d="M276 62c7-10 16-11 21-4s13 4 17-4"
        stroke="#FF5E07"
        strokeWidth="4.7"
        strokeLinecap="round"
      />
      <path
        d="M4 118c8-10 17-11 22-4s12 4 16-4"
        stroke="#FF70C6"
        strokeWidth="4.7"
        strokeLinecap="round"
      />
      <path
        d="M283 220c7-9 15-10 20-4s11 3 14-4"
        stroke="#FF70C6"
        strokeWidth="4.7"
        strokeLinecap="round"
      />
      <circle cx="50" cy="91" r="6.3" fill="#FF70C6" />
      <circle cx="287" cy="148" r="12.6" fill="#FA7F12" />
      <circle cx="276" cy="121" r="6.3" fill="#FA7F12" />
      <circle cx="154" cy="3" r="3.1" fill="#FF70C6" />
      <circle cx="168" cy="22" r="14.1" fill="#FF70C6" />
      <path d="M232 8l4 10 10 4-10 4-4 10-4-10-10-4 10-4 4-10Z" fill="#FF70C6" />
      <path d="M45 185l6 15 15 6-15 6-6 15-6-15-15-6 15-6 6-15Z" fill="#FA7F12" />
    </svg>
  );
}