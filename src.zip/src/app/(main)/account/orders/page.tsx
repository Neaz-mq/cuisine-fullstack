import Link from "next/link";
import { auth } from "@/auth";
import { prisma } from "@/lib/prisma";
import Container from "@/components/Container";
import { redirect } from "next/navigation";
import { formatOrderId } from "@/lib/format-order-id";
import OrderAgainButton from "./OrderAgainButton";
import { formatAmount, isPositiveAmount } from "@/lib/currency-format";

/**
 * src/app/(main)/account/orders/page.tsx
 *
 * "My Orders" page — protected by middleware.ts (authConfig.callbacks.authorized
 * already blocks unauthenticated access to anything under /account), but we
 * also redirect defensively here in case this page is ever reached directly
 * during a session edge-case (e.g. token just expired).
 *
 * Fetches directly via Prisma instead of calling GET /api/orders/mine over
 * HTTP — this is a Server Component, so there's no benefit to a network
 * round-trip to our own API; the /mine route stays available for any future
 * client-side (e.g. mobile app, polling) use case.
 */

const STATUS_STYLES: Record<string, string> = {
  PLACED: "bg-blue-100 text-blue-700",
  PREPARING: "bg-yellow-100 text-yellow-700",
  OUT_FOR_DELIVERY: "bg-orange-100 text-orange-700",
  DELIVERED: "bg-green-100 text-green-700",
  CANCELLED: "bg-red-100 text-red-700",
};

const STATUS_LABELS: Record<string, string> = {
  PLACED: "Placed",
  PREPARING: "Preparing",
  OUT_FOR_DELIVERY: "Out for delivery",
  DELIVERED: "Delivered",
  CANCELLED: "Cancelled",
};

// A dine-in order was never "out for delivery" — same backend enum value,
// different customer-facing wording (see project notes).
function statusLabel(status: string, orderType: "DELIVERY" | "DINE_IN") {
  if (status === "OUT_FOR_DELIVERY" && orderType === "DINE_IN") return "Ready to serve";
  return STATUS_LABELS[status] ?? status;
}

function fulfillmentLabel(order: {
  orderType: "DELIVERY" | "DINE_IN";
  shippingMethod: string | null;
  table: { label: string } | null;
}) {
  if (order.orderType === "DINE_IN") {
    return `Table ${order.table?.label ?? "—"}`;
  }
  if (order.shippingMethod === "UBER_EATS") return "Uber Eats";
  if (order.shippingMethod === "FOOD_PANDA") return "Food Panda";
  if (order.shippingMethod === "OWN_DELIVERY") return "Our Own Delivery";
  return "—";
}

export default async function MyOrdersPage() {
  const session = await auth();

  if (!session?.user?.id) {
    redirect("/login");
  }

  const orders = await prisma.order.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: "desc" },
    include: { items: { include: { menuItem: true } }, table: true },
  });

  return (
    <Container>
      <div className="bg-white min-h-screen px-4 py-8 md:px-6 max-w-4xl mx-auto">
        <h1 className="text-2xl md:text-3xl font-semibold text-gray-800 mb-8">
          My Orders
        </h1>

        {orders.length === 0 ? (
          <div className="text-center py-16 border border-dashed border-gray-300 rounded-md">
            <p className="text-gray-500 mb-4">You haven&apos;t placed any orders yet.</p>
            <Link
              href="/order"
              className="inline-block bg-[#FF4C15] text-white font-semibold px-5 py-2 rounded-sm hover:bg-orange-600 transition-colors"
            >
              Browse the menu
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => {
              // Each order carries its own currency, so a list can legitimately
              // mix them — an old order placed in another currency must not be
              // relabelled with today's.
              const units = order.currencyMinorUnits;
              const money = (value: { toFixed(dp: number): string }) =>
                formatAmount(value.toFixed(units), order.currency);

              return (
              <div
                key={order.id}
                className="border border-gray-200 rounded-md p-5"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-4 pb-4 border-b border-gray-100">
                  <div>
                    <p className="text-xs text-gray-400">Order ID</p>
                    <p className="text-sm font-mono text-gray-700">{formatOrderId(order.id)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-400">Placed on</p>
                    <p className="text-sm text-gray-700">
                      {order.createdAt.toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })}
                    </p>
                  </div>
                  <span
                    className={`text-xs font-semibold px-3 py-1 rounded-full ${
                      STATUS_STYLES[order.status] ?? "bg-gray-100 text-gray-700"
                    }`}
                  >
                    {statusLabel(order.status, order.orderType)}
                  </span>
                  {order.status !== "DELIVERED" && order.status !== "CANCELLED" && (
                    <Link
                      href={`/track/${order.id}`}
                      className="text-xs font-medium text-[#FF4C15] hover:underline"
                    >
                      Track order →
                    </Link>
                  )}
                  {(order.status === "DELIVERED" || order.status === "CANCELLED") && (
                    <OrderAgainButton
                      items={order.items.map((item) => ({
                        menuItemId: item.menuItemId,
                        title: item.menuItem.title,
                        // OrderAgainButton একটা client component আর
                        // cart-এ দাম দিয়ে গুণ-যোগ হয়, তাই boundary-তে
                        // number-এ রূপান্তর।
                        //
                        // ⚠️ item.price (order-এর সময়ের দাম) নয়,
                        // menuItem.price (আজকের দাম) — ইচ্ছাকৃত: আবার
                        // অর্ডার করলে আজকের দামেই হবে।
                        price: item.menuItem.price.toNumber(),
                        quantity: item.quantity,
                        imageUrl: item.menuItem.imageUrl,
                        isAvailable: item.menuItem.isAvailable,
                      }))}
                    />
                  )}
                </div>

                <div className="space-y-2 mb-4">
                  {order.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex justify-between text-sm text-gray-700"
                    >
                      <span>
                        {item.menuItem.title}{" "}
                        <span className="text-gray-400">x{item.quantity}</span>
                      </span>
                      <span>{money(item.price.times(item.quantity))}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-dashed border-gray-200">
                  <span className="text-sm text-gray-500">
                    {fulfillmentLabel(order)}
                    {" · "}
                    {order.paymentMethod === "COD"
                      ? order.orderType === "DINE_IN"
                        ? "Pay at Table"
                        : "Cash on Delivery"
                      : "Online Payment"}
                  </span>
                  <div className="text-right">
                    <span className="font-bold text-[#2C6252]">
                      {money(order.totalAmount)}
                    </span>
                    {/* One quiet line rather than the full breakdown — this is
                        a list, and the tracking page already itemises it. Tax
                        is called out because an EU customer needs to see it
                        somewhere on the record. */}
                    {isPositiveAmount(order.taxAmount.toFixed(units)) && (
                      <p className="text-xs text-gray-400">
                        incl. {money(order.taxAmount)} {order.taxName}
                      </p>
                    )}
                  </div>
                </div>
              </div>
              );
            })}
          </div>
        )}
      </div>
    </Container>
  ); 
}
