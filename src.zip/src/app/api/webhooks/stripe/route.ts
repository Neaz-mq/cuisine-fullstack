import { NextResponse } from "next/server";
import type Stripe from "stripe";
import { getStripeClient } from "@/lib/stripe";
import { prisma } from "@/lib/prisma";
import { sendOrderConfirmationEmail } from "@/lib/send-order-confirmation-email";
import { syncCustomerToAudience } from "@/lib/resend";
import { cancelOrder } from "@/lib/cancel-order";
import { recordExternalRefunds, refundOrder } from "@/lib/refund-order";

/**
 * src/app/api/webhooks/stripe/route.ts
 *
 * একটা online order-কে paymentStatus PAID করার এবং confirmation email
 * পাঠানোর একমাত্র জায়গা এটাই। /api/checkout/create-session-এর
 * success_url শুধু browser-কে কোথায় পাঠানো হবে তা ঠিক করে — সেটা
 * কখনোই payment হয়েছে তার প্রমাণ নয়, কারণ customer টাকা না দিয়েও ওই
 * URL-এ পৌঁছাতে পারে (back button, URL অনুমান, ইত্যাদি)। শুধুমাত্র
 * Stripe-এর নিজের signature-verified event বিশ্বাস করা হয়।
 *
 * Local testing-এ Stripe CLI দিয়ে event forward করতে হবে:
 *   stripe listen --forward-to localhost:3000/api/webhooks/stripe
 * সেটা যে whsec_... secret ছাপে তা .env-এর STRIPE_WEBHOOK_SECRET-এ
 * বসিয়ে dev server hard restart দিন (env পরিবর্তনে hot reload যথেষ্ট
 * নয়)। এই route থেকে 400 এলে প্রথমেই দেখবেন secret-টা পুরোপুরি কপি
 * হয়েছে কিনা এবং চলমান `stripe listen` যা দেখাচ্ছে তার সাথে মেলে কিনা।
 *
 * এই ফাইলের তিনটে নীতি, তিনটে আসল bug থেকে শেখা:
 *
 * ১. দাবি সবসময় atomic — findUnique করে পড়ে তারপর update নয়। Stripe
 *    at-least-once deliver করে, তাই একই event দুবার আসতেই পারে;
 *    পড়া-তারপর-লেখা করলে দুটো delivery-ই "এখনো PAID হয়নি" দেখে দুবার
 *    email পাঠাতো।
 *
 * ২. Payment record করার পরের কোনো side effect (email, audience sync)
 *    কখনো response fail করাতে পারবে না। আগে email throw করলে outer
 *    catch 500 দিত, Stripe retry করতো, কিন্তু order ততক্ষণে PAID — তাই
 *    idempotency guard short-circuit করতো আর email আর কোনোদিনই যেত না।
 *    টাকা নেওয়া হয়েছে, customer কিছুই পায়নি।
 *
 * ৩. session.expired শুধু status বদলায় না, দাবি করা মূল্য ফেরতও দেয় —
 *    cancelOrder() stock, coupon, gift card সব reverse করে। আগে শুধু
 *    CANCELLED লেখা হতো, ফলে abandoned checkout-এ customer-এর gift card
 *    balance চিরতরে হারিয়ে যেত।
 */
export async function POST(request: Request) {
  const signature = request.headers.get("stripe-signature");
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!signature || !webhookSecret) {
    console.error("Stripe webhook: missing signature header or STRIPE_WEBHOOK_SECRET");
    return NextResponse.json({ error: "Webhook not configured" }, { status: 400 });
  }

  // Signature verification-এ Stripe যে exact bytes পাঠিয়েছে সেটাই লাগে।
  // .text() আগে string-এ decode করে, যা সূক্ষ্ম encoding পার্থক্য তৈরি
  // করতে পারে; arrayBuffer() -> Buffer হুবহু bytes রাখে, যা Stripe-এর
  // SDK HMAC যাচাইয়ের জন্য চায়।
  const rawBodyBuffer = Buffer.from(await request.arrayBuffer());

  let event: Stripe.Event;
  try {
    event = getStripeClient().webhooks.constructEvent(rawBodyBuffer, signature, webhookSecret);
  } catch (err) {
    console.error(
      "Stripe webhook signature verification failed:",
      err instanceof Error ? err.message : err
    );
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;

        // Gift card বিক্রি বন্ধ — নতুন কোনো gift_card session আর তৈরি
        // হয় না। পুরোনো কোনো session দেরিতে এলে সেটা order নয়, তাই
        // order path-এ না পাঠিয়ে লগ করে ছেড়ে দেওয়া হয় (Stripe-কে 200)।
        if (session.metadata?.purpose === "gift_card") {
          console.warn("Stripe webhook: ignoring gift_card session — gift cards are disabled", session.id);
          break;
        }

        /**
         * Reservation-এর অগ্রিম। কোনো Order জড়িত নয়, তাই আলাদা path।
         *
         * ⚠️ দাবিটা updateMany দিয়ে, `status: "PENDING"` শর্ত সহ —
         * Stripe একই event একাধিকবার পাঠাতে পারে (at-least-once), আর
         * দ্বিতীয়বার এলে count 0 আসে বলে কিছুই ঘটে না। findFirst করে
         * `if (status === "PENDING")` লিখলে দুটো delivery একসাথে এসে
         * দুটোই পাশ করত।
         */
        const reservationId = session.metadata?.reservationId;
        if (session.metadata?.purpose === "reservation_deposit" && reservationId) {
          const claimed = await prisma.reservation.updateMany({
            where: { id: reservationId, status: "PENDING" },
            data: { status: "CONFIRMED", depositPaidAt: new Date() },
          });
          if (claimed.count === 0) {
            // হয় duplicate delivery, নয় ইতিমধ্যে বাতিল — দুটোই
            // স্বাভাবিক, তাই error নয়।
            console.log("Reservation deposit already settled", reservationId);
          }
          break;
        }

        const orderId = session.metadata?.orderId;
        if (orderId) {
          await handleOrderPaid(orderId, session);
        }
        break;
      }

      case "charge.refunded": {
        // Stripe dashboard থেকে সরাসরি refund করা হয়েছে।
        //
        // এটা না সামলালে দুই জায়গায় দুই সত্য থাকত: Stripe বলত টাকা ফেরত
        // গেছে, আমাদের admin বলত order সম্পূর্ণ PAID। হিসাব মেলানোর সময়
        // সেটাই সবচেয়ে বিভ্রান্তিকর।
        //
        // আমাদের নিজের UI থেকে করা refund-ও এই event হয়ে ফিরে আসে।
        //
        // ⚠️ `metadata` অবশ্যই পাঠাতে হবে — এটাই ছিল একটা race-এর মূল।
        //
        // refundOrder() প্রতিটা Stripe refund-এ metadata.refundId বসায়,
        // কিন্তু এই map() আগে সেটা ফেলে দিত। ফলে recordExternalRefunds
        // চিনতে পারত কেবল stripeRefundId দিয়ে — যা refundOrder Stripe-এর
        // উত্তর পাওয়ার *পরে* লেখে। এই event প্রায়ই তার আগেই পৌঁছে যায়,
        // তখন একটা দ্বিতীয় Refund row তৈরি হতো আর সফল refund-টা
        // admin-এ "Stripe refused the refund" দেখাত।
        const charge = event.data.object as Stripe.Charge;
        const paymentIntentId =
          typeof charge.payment_intent === "string"
            ? charge.payment_intent
            : charge.payment_intent?.id;

        if (paymentIntentId) {
          await recordExternalRefunds(
            paymentIntentId,
            (charge.refunds?.data ?? []).map((r) => ({
              id: r.id,
              amount: r.amount,
              reason: r.reason,
              metadata: r.metadata ?? null,
            }))
          );
        }
        break;
      }

      case "checkout.session.expired": {
        const session = event.data.object as Stripe.Checkout.Session;

        /**
         * ⚠️ গ্রাহক টাকা না দিয়ে Stripe-এর পাতা ছেড়ে গেছেন — ধরে রাখা
         * টেবিলটা এখনই ছাড়তে হবে।
         *
         * না ছাড়লে একটা PENDING reservation ওই slot-টা চিরকাল আটকে
         * রাখত (isTableAvailable বাতিল ছাড়া সব status-কে দখল ধরে),
         * অথচ কেউ কোনোদিন টাকা দেয়নি। order-এর ক্ষেত্রে নিচে ঠিক এই
         * একই যুক্তিতে cancelOrder ডাকা হয়।
         *
         * এখানে stock/coupon/gift card ফেরানোর কিছু নেই, তাই একটা
         * সরল status বদলই যথেষ্ট — তবে দাবিটা আবারও updateMany দিয়ে,
         * যাতে completed event-এর সাথে race লাগলে ইতিমধ্যে CONFIRMED
         * হয়ে যাওয়া booking বাতিল না হয়ে যায়।
         */
        const expiredReservationId = session.metadata?.reservationId;
        if (session.metadata?.purpose === "reservation_deposit" && expiredReservationId) {
          await prisma.reservation.updateMany({
            where: { id: expiredReservationId, status: "PENDING" },
            data: { status: "CANCELLED" },
          });
          break;
        }

        const orderId = session.metadata?.orderId;

        if (orderId) {
          // Customer টাকা না দিয়ে Stripe-এর পেজ ছেড়ে গেছে। শুধু
          // CANCELLED লিখলে যথেষ্ট নয় — cancelOrder() deduct হওয়া stock
          // ফেরত দেয়, coupon-এর usageCount কমায়, আর সবচেয়ে জরুরি, gift
          // card balance ফেরত দেয়। ওটা না করলে customer-এর টাকা এমন
          // একটা order-এ আটকে থাকতো যার জন্য কেউ কখনো টাকা দেয়নি।
          //
          // completed event-এর সাথে race লাগলে (order ততক্ষণে PAID আর
          // DELIVERED-এর পথে) cancelOrder নিজেই ok:false ফেরত দেয়,
          // throw করে না — তাই এখানে আলাদা guard লাগে না।
          const result = await cancelOrder(orderId, "Stripe checkout session expired");
          if (!result.ok) {
            console.error("Could not cancel expired checkout order", orderId, result.error);
          }
        }
        break;
      }

      default:
        // এই flow-এর সাথে এখনো প্রাসঙ্গিক নয় এমন event type.
        break;
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Stripe webhook handler error:", error);
    return NextResponse.json({ error: "Webhook handler failed" }, { status: 500 });
  }
}

/**
 * Order-কে PAID হিসেবে দাবি করে, তারপর confirmation email আর marketing
 * sync চালায়। দাবিটা updateMany দিয়ে — যে call count 1 পায় সেটাই
 * একমাত্র email পাঠায়, বাকি duplicate delivery চুপচাপ ফিরে যায়।
 */
async function handleOrderPaid(orderId: string, session: Stripe.Checkout.Session) {
  // ⚠️ payment_intent এখানেই ধরে রাখতে হয়, আর কোথাও নয়।
  //
  // Stripe-এর Refunds API একটা payment intent বা charge id ছাড়া কাজ করে
  // না, অথচ আগে এই webhook শুধু metadata.orderId পড়ে বাকি সব ফেলে দিত।
  // ফলে টাকা নেওয়া যেত কিন্তু ফেরত দেওয়ার কোনো পথ থাকত না — এই একটা
  // লাইন না থাকায় গোটা refund feature-ই অসম্ভব ছিল।
  const paymentIntentId =
    typeof session.payment_intent === "string"
      ? session.payment_intent
      : session.payment_intent?.id;

  const claim = await prisma.order.updateMany({
    where: { id: orderId, paymentStatus: { not: "PAID" } },
    data: {
      paymentStatus: "PAID",
      ...(paymentIntentId ? { stripePaymentIntentId: paymentIntentId } : {}),
    },
  });

  // count 0 মানে অন্য কোনো delivery ইতিমধ্যে এটা সামলে ফেলেছে।
  if (claim.count !== 1) return;

  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: { items: { include: { menuItem: true } } },
  });
  if (!order) {
    console.error("Order vanished between claim and read", orderId);
    return;
  }

  // ⚠️ The customer paid for an order that was already CANCELLED — staff
  // cancelled it while they were still on Stripe's page. cancelOrder()
  // already gave back the coupon, gift card and points, but the card money
  // just arrived and nobody will cook this order. Send it straight back
  // rather than silently keeping it.
  if (order.status === "CANCELLED") {
    const refund = await refundOrder({
      orderId,
      reason: "Paid after the order was cancelled",
    });
    if (!refund.ok) {
      console.error("⚠️ Could not refund payment for a cancelled order", orderId, refund.error);
    }
    return;
  }

  // ⚠️ এখান থেকে নিচের কিছুই throw করে webhook fail করাতে পারবে না।
  // টাকা নেওয়া হয়ে গেছে এবং DB-তে record হয়ে গেছে — Resend সাময়িকভাবে
  // বন্ধ থাকলে সেটা Stripe-কে 500 দেখানোর কারণ নয়, কারণ retry-তে উপরের
  // claim আর পাস করবে না আর email চিরতরে হারিয়ে যাবে।
  try {
    await sendOrderConfirmationEmail(order);
  } catch (error) {
    // TODO: retry queue / outbox — আপাতত অন্তত Sentry আর log-এ থাকে,
    // যাতে দরকার হলে হাতে পাঠানো যায়।
    console.error("Confirmation email failed for paid order", orderId, error);
  }

  // ⚠️ marketingConsent এই Order row-তে আগে থেকেই থাকতে হবে — সেটা
  // /api/checkout/create-session-এ order তৈরির সময় (Stripe redirect-এর
  // আগে) capture করা হয়, ঠিক যেভাবে COD order-এ /api/orders করে। এই
  // route শুধু পড়ে, customer-কে কখনো জিজ্ঞেস করে না।
  if (order.marketingConsent && order.email) {
    try {
      await syncCustomerToAudience({
        email: order.email,
        firstName: order.firstName,
        lastName: order.lastName,
      });

      if (order.userId) {
        await prisma.user.update({
          where: { id: order.userId },
          data: { marketingConsent: true, marketingConsentAt: new Date() },
        });
      }
    } catch (error) {
      console.error("Marketing audience sync failed for order", orderId, error);
    }
  }
}
