import { NextResponse } from "next/server";
import { auth } from "@/auth";
import {
  findValidCoupon,
  calcDiscountAmount,
  getCustomerKey,
  resolveOrderItems,
} from "@/lib/order-checkout-shared";
import { checkRateLimit } from "@/lib/rate-limit";
import { parseBody } from "@/lib/validations/parse";
import { validateCouponSchema } from "@/lib/validations/coupon";

/**
 * src/app/api/coupons/validate/route.ts
 *
 * POST /api/coupons/validate -> public, unauthenticated. Lets the checkout
 * page preview a discount before submitting the order (so the customer
 * sees the real amount before clicking "Confirm your order"), including
 * every v2 rule that can be previewed: expiry, minimum order value, item/
 * category restriction, the global usage cap, and — when we know who's
 * asking (logged-in userId, or the phone number they've typed into
 * billing so far) — their personal per-customer cap too.
 *
 * Takes the cart's `items` (not a bare subtotal) so it can resolve real
 * prices/categoryIds server-side — required for item/category-restricted
 * coupons, whose discount only applies to a subset of the cart's lines,
 * and safer in general since a client-reported subtotal was never
 * trustworthy anyway.
 *
 * This is a PREVIEW only — it does not consume the coupon. The coupon is
 * only actually spent when an order is created (see consumeCoupon in
 * order-checkout-shared.ts, called from /api/orders and
 * /api/checkout/create-session), inside the same DB transaction as the
 * order itself. That's also where the discount is authoritatively
 * recomputed from server-resolved item prices.
 */
export async function POST(request: Request) {
  try {
    // Coupon codes are guessable strings, so this endpoint is an obvious
    // brute-force target (script through WELCOME1, WELCOME2, ... until one
    // sticks). A generous but real cap per IP keeps normal "typo, try
    // again" usage unaffected while making that kind of scripted guessing
    // impractical. See rate-limit.ts for the in-memory-vs-Redis tradeoff.
    const rateLimitResult = checkRateLimit(request, "coupon-validate", {
      limit: 20,
      windowMs: 60_000,
    });
    if (!rateLimitResult.allowed) {
      return NextResponse.json(
        { error: "Too many attempts. Please wait a moment and try again." },
        { status: 429, headers: { "Retry-After": String(rateLimitResult.retryAfterSeconds) } }
      );
    }

    const parsed = await parseBody(request, validateCouponSchema);
    if (parsed instanceof NextResponse) return parsed;
    const { code, items, phone, orderType } = parsed;

    const resolution = await resolveOrderItems(items);
    if (!resolution.ok) {
      return NextResponse.json({ error: resolution.error }, { status: 400 });
    }
    const resolvedItems = resolution.items;

    const session = await auth();
    const customerKey = getCustomerKey(session?.user?.id, phone);

    const result = await findValidCoupon(code, resolvedItems, customerKey, { orderType });
    if (!result.ok) {
      return NextResponse.json({ error: result.error }, { status: 400 });
    }

    const discountAmount = calcDiscountAmount(result.eligibleSubtotal, result.coupon);

    return NextResponse.json({
      code: result.coupon.code,
      type: result.coupon.type,
      percentOff: result.coupon.percentOff,
      /**
       * ⚠️ `Number()` — এখানে একটা সত্যিকারের বাগ ছিল।
       *
       * `fixedOff` Prisma-র `Decimal`, আর `NextResponse.json()` সেটাকে
       * **string** বানিয়ে পাঠায় ("5"), number নয়। client-এ
       * (`Carts.tsx`) মাঠটার ধরন লেখা `number | null`, তাই TypeScript
       * কিছুই বলেনি — কিন্তু render-এর সময় `fixedOff.toFixed(2)` চলত
       * একটা string-এর উপরে, আর "toFixed is not a function" দিয়ে
       * পুরো cart পাতাটা error boundary-তে চলে যেত।
       *
       * শতাংশের কুপনে (`PERCENT`) ওই শাখাটাই চলত না, তাই বাগটা কেবল
       * FIXED কুপনে দেখা যেত — ধরা কঠিন হওয়ার কারণ সেটাই।
       *
       * নিচের `discountAmount` আর `eligibleSubtotal` আগে থেকেই
       * `.toNumber()` করা; এই একটা মাঠ বাদ পড়ে গিয়েছিল।
       */
      fixedOff:
        result.coupon.fixedOff === null ? null : Number(result.coupon.fixedOff),
      // number-এ রূপান্তর — কারণ /api/gift-cards/validate-এর একই
      // মন্তব্যে ব্যাখ্যা করা: এটা preview, আসল হিসাব নয়।
      discountAmount: discountAmount.toNumber(),
      eligibleSubtotal: result.eligibleSubtotal.toNumber(),
    });
  } catch (error) {
    console.error("POST /api/coupons/validate error:", error);
    return NextResponse.json(
      { error: "Failed to validate coupon" },
      { status: 500 }
    );
  }
}